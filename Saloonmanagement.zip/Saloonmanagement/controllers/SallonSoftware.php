<?php
/**
 * Created by PhpStorm.
 * User: User
 * Date: 5/13/17
 * Time: 1:26 PM
 */

class SallonSoftware extends CI_Controller {
    function __construct(){
        parent::__construct();
        date_default_timezone_set("Asia/Kolkata");
        $this->load->model(array('Admin_model'));

    }

    private function isLogin(){

     // return ($this->session->userdata('logged_in') == true)? true : false ;
        if( $this->session->userdata('logged_in') ){
             return true;
            }
        else{
            return false;
        }
    }

    public function fForgotPasswordGetFunction(){
        if ($this->input->is_ajax_request()) {
            $user_name=  trim($this->input->post('user_name'));
            $result = $this->Admin_model->getDataRow('users', array( 'user_name' =>$user_name, 'user_status' => 1));
            if($result !=false){

                $pass = $this->randomPasswordgenerator();

                $data=array(
                    'password' => md5($pass)
                );
                $update = $this->Admin_model->updateInfo('users',array('user_id' =>$result->user_id ),$data);
                if($update == true) {

                    $info = array('pass' => $pass, 'name' =>$result->name, 'phone' =>$result->phone );

                    $sms_admin_msg = "Password change from ". $info['name']." , Phone :  ".$info['phone'];

                    $sms_cust_msg = "Dear ". $info['name'].", your new password is :  ".$info['pass'].", Thank You staying with us Tel: 022 - 22623050 / 51.";

                    $this->sendTextMessage($info, $sms_admin_msg, $sms_cust_msg);

                    echo json_encode(array('error' => false, 'message' => 'Password is send to contact number.'));
                }

               // echo json_encode(array('error' => false, 'message' => $result->phone));
            } else{
                echo json_encode(array('error' => true, 'message' => 'User not exist!'));
            }

        } else {
            echo json_encode(array('error' => true, 'message' => 'Direct access not allowed!'));
        }
    }

    public function sendTextMessage($info, $sms_admin_msg, $sms_cust_msg){

        $xml_data ='<?xml version="1.0"?>
					<parent>
					<child>
					<user>shreeji</user>
					<key>cef739d616XX</key>
					<mobile>'.$info['phone'].'</mobile>
					<message>'.$sms_cust_msg.'</message>
					<accusage>1</accusage>
					<senderid>sreeji</senderid>
					</child>

					<child>
					<user>shreeji</user>
					<key>cef739d616XX</key>
					<mobile>+918286108870</mobile>
					<message>'.$sms_admin_msg.'</message>
					<accusage>1</accusage>
					<senderid>sreeji</senderid>
					</child>
					</parent>';

        $URL = "http://smst.eweb.co.in/submitsms.jsp?";

        $ch = curl_init($URL);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_ENCODING, 'UTF-8');
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/xml'));
        curl_setopt($ch, CURLOPT_POSTFIELDS, "$xml_data");
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        $output = curl_exec($ch);
        curl_close($ch);
    }

    public function index(){
    if($this->isLogin() == true){
        if($this->session->userdata('user_role') == 0){
            redirect('my-profile');
        } else{
            redirect('dashboard');
        }

    } else{
        redirect('login');
    }
  }
    public function dashboard(){
        if($this->isLogin() && $this->session->userdata('user_role') == 1){
          //  $this->load->view('body/dashboard');
            $data['all_users']=$this->Admin_model->getDataActiveClient();
            $data['all_users_ac']=$this->Admin_model->getDataActiveClientAll();
            $data['services'] = $this->Admin_model->getData('service_tbl', array('status' => 1),'','');
            $data['all_packages']=$this->Admin_model->getData('package_tbl', array('status' => 1),'','');

            $data['body']= 'dashboard';
            $data['tab']='dashboard';
            $this->load->view('general/header');
            $this->load->view('general/left-menu',$data);
            $this->load->view('body/main', $data);
            $this->load->view('general/footer');
        } elseif($this->isLogin() && $this->session->userdata('user_role') == 0){
             redirect('my-profile');
        }else{
            redirect('login');
        }
    }
    protected function randomPasswordgenerator() {
        $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $charactersLength = strlen($characters);
        $randomString = '';
        for ($i = 0; $i < 8; $i++) {
            $randomString .= $characters[rand(0, $charactersLength - 1)];
        }
        return $randomString;
    }

    public function autoGPassword() {
        if ($this->input->is_ajax_request()) {
            echo json_encode(array('pass' => $this->randomPasswordgenerator()));
        } else {
            echo json_encode(array('pass' => 'error'));
        }
    }
    function validate_phone_number($value) {
        $value = trim($value);
        $match = '/^\(?[0-9]{3}\)?[-. ]?[0-9]{3}[-. ]?[0-9]{4}$/';
        $replace = '/^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$/';
        $return = '($1) $2-$3';
        if (preg_match($match, $value)) {
            return preg_replace($replace, $return, $value);
        } else {
            $this->form_validation->set_message('validate_phone_number', 'Invalid phone number.');
            return false;
        }
    }
    public function addUser(){
        if($this->isLogin()){
            //  $this->load->view('body/dashboard');
            $this->form_validation->set_rules('name', 'Full Name', 'trim|required|xss_clean|min_length[3]');
            $this->form_validation->set_rules('package', 'Full Name', 'trim|required|xss_clean');
            $this->form_validation->set_rules('user_name', 'User name or Email', 'trim|required|xss_clean');
            $this->form_validation->set_rules('password', 'Password', 'trim|required|xss_clean|min_length[5]');
            $this->form_validation->set_rules('phone', 'Phone', 'trim|required|xss_clean');

            if ($this->form_validation->run()) {
                $package_details=$this->Admin_model->getUserData('package_tbl',array('package_id'=>$this->input->post('package')));
               //print_r($package_details); exit;
                $reg_time=date('Y-m-d');

                $date = date("Y-m-d");
                $month = $package_details->package_period;
                $expire_on = strtotime(date("Y-m-d", strtotime($date)) . " +".$month." month");
                $expire_on = date("Y-m-d",$expire_on);
                    $data=array(
                        'name'=>$this->input->post('name'),
                        'user_name'=>trim($this->input->post('user_name')),
                        'phone'=>$this->input->post('phone'),
                        'password'=>md5(trim($this->input->post('password'))),
                        'package_id' => $this->input->post('package'),
                        'client_balance' =>$package_details->package_price ,
                        'bonus' => $package_details->bonus,
                        'current_balance' => ($package_details->package_price + $package_details->bonus ),
                        'family_members' =>  $this->input->post('family_members'),
                        'user_role'=>0,
                        'user_status'=>1,
                        'registered_date'=>$reg_time,
                        'expire_on' =>$expire_on
                    );
                    $result = $this->Admin_model->dataInsert('users',$data);
                    if($result !=false) {
                       // $this->sendEmail($this->input->post('email'), $data,'email/email-notification');

                        $info = array('pass' => trim($this->input->post('password')), 'name' =>$this->input->post('name'), 'phone' =>$this->input->post('phone') );

                        $sms_admin_msg = " New client registration, Name ". $info['name']." , Phone :  ".$info['phone'];

                        $sms_cust_msg = "Dear ". $info['name']." congratulation for registration, your password is :  ".$info['pass'].", Thanks staying with us Tel: 022 - 22623050 / 51.";

                        $this->sendTextMessage($info ,$sms_admin_msg, $sms_cust_msg);
                        $this->session->set_flashdata('registration_success','Registration Successful');
                       
                       //$data['registration_success']='Registartion Successful';
                        redirect('add-user');

                    } 
                   


            }
             
            $data['all_package']=$this->Admin_model->getData('package_tbl','','','');
            $data['body']= 'add-user';
            $data['tab']='register';

            $this->load->view('general/header');
            $this->load->view('general/left-menu',$data);
            $this->load->view('body/main', $data);
            $this->load->view('general/footer');
        } else{
            redirect('login');
        }
    }
    public function addPackage(){
        if($this->isLogin()){
            $this->form_validation->set_rules('package_name', 'package name', 'trim|required|xss_clean');
            $this->form_validation->set_rules('package_price', 'package price', 'trim|required|xss_clean|numeric');
            $this->form_validation->set_rules('package_period', 'package period', 'trim|required|xss_clean|numeric');
            $this->form_validation->set_rules('package_bonus', 'package bonus', 'trim|required|xss_clean|numeric');
            if ($this->form_validation->run()) {
                $data=array(
                    'package_name' => $this->input->post('package_name'),
                    'package_price' => $this->input->post('package_price'),
                    'package_period' => $this->input->post('package_period'),
                    'bonus' => $this->input->post('package_bonus'),
                    'added_date' =>date("Y-m-d H:i:s"),
                    'status' => 1
                );
                $result = $this->Admin_model->dataInsert('package_tbl',$data);
                if($result !=false) {
                    // $this->sendEmail($this->input->post('email'), $data,'email/email-notification');
                    $this->session->set_flashdata('success','Package added successful.');
                    redirect('add-package');
                }
            }
            $data['all_packages']=$this->Admin_model->getData('package_tbl', array('status' => 1),'','');
            $data['body']= 'add-package';
            $data['tab']='package';
            $this->load->view('general/header');
            $this->load->view('general/left-menu',$data);
            $this->load->view('body/main', $data);
            $this->load->view('general/footer');
        } else{
            redirect('login');
        }
    }
    public function addService(){
        if($this->isLogin()){
            $this->form_validation->set_rules('service_name', 'service name', 'trim|required|xss_clean');
            $this->form_validation->set_rules('service_price', 'service price', 'trim|required|xss_clean|numeric');
            if ($this->form_validation->run()) {
                $data=array(
                    'service_name' => $this->input->post('service_name'),
                    'service_price' => $this->input->post('service_price'),
                    'status' => 1
                );
                $result = $this->Admin_model->dataInsert('service_tbl',$data);
                if($result !=false) {
                    // $this->sendEmail($this->input->post('email'), $data,'email/email-notification');
                    $this->session->set_flashdata('success','Service added successful.');
                    redirect('add-service');
                }
            }
            
            $data['services'] = $this->Admin_model->getData('service_tbl', array('status' => 1),'','');

            $data['body']= 'add-service';
            $data['tab']='service';
            $this->load->view('general/header');
            $this->load->view('general/left-menu',$data);
            $this->load->view('body/main', $data);
            $this->load->view('general/footer');
        } else{
            redirect('login');
        }
    }
    public function takeService(){
        if($this->isLogin()){
            //  $this->load->view('body/dashboard');
            $data['users']=$this->Admin_model->getData('users',array('user_status' =>1, 'user_role'=>0),'','');
            $data['services']=$this->Admin_model->getData('service_tbl','','','');
            $data['services_2']=$this->Admin_model->getData('service_tbl','','','');

            $this->form_validation->set_rules('user_id', 'user name', 'trim|required|xss_clean');
            $this->form_validation->set_rules('service_id[]', 'service name', 'trim|xss_clean');
            $this->form_validation->set_rules('total_amount', 'total to deduct', 'trim|xss_clean');
            $this->form_validation->set_rules('total_amount', 'total to deduct', 'trim|xss_clean');

           $service_list = $this->input->post('service_id');
            if ($this->form_validation->run()) {
                $amount_to_deduct = ($this->input->post('total_amount') && $this->input->post('total_amount') !='')? $this->input->post('total_amount'):0;
                $check_balance = $this->Admin_model->checkBalance($this->input->post('user_id'), $amount_to_deduct);
                if($check_balance == true ){
                    $package_details = $this->Admin_model->getPackageName('service_tbl',$service_list);
                    $package_names='';
                   foreach($package_details as $package_details){
                       $package_names = $package_names.','.trim(ucfirst($package_details->service_name));
                   }
                    $f_members=$this->input->post('family_members');
                    $f_list='';
                    for($j = 0; $j < sizeof($f_members); $j++){
                      $f_list =  $f_list.','.trim(ucfirst($f_members[$j]));
                    }

                   $update = $this->Admin_model->updateBalance('users', $this->input->post('user_id'),$amount_to_deduct);

                  //  echo $this->input->post('total_amount').'<br>';
                  //  echo $this->db->last_query();exit;
                   if($update == true){
                         $add_time=date('Y-m-d H:i:s');

                    $data=array(
                        'user_id'=>$this->input->post('user_id'),
                        'family_members'=>$f_list,
                        'service_id'=> $package_names,
                        'remark' =>$this->input->post('remark'),
                        'tax' =>$this->input->post('tax'),
                        'price'=>$amount_to_deduct,
                        'date' =>$add_time
                    );
                    $result = $this->Admin_model->dataInsert('clients_avail_service',$data);
                    if($result !=false) {
                        $this->session->set_flashdata('success','Request successful');
                        redirect('take-service');
                    }
                   } else {
                        $this->session->set_flashdata('no_balance', ' Request fail due to internal error service');
                    redirect('take-service');
                   }
                  
                } else{
                    $this->session->set_flashdata('no_balance', $check_balance->name.' has low balance to avail this service');
                    redirect('take-service');
                }

            }
            $data['tax_percent'] = 15;

            $data['body']= 'take-service';
            $data['tab']='tabel_service';
            $this->load->view('general/header');
            $this->load->view('general/left-menu',$data);
            $this->load->view('body/main', $data);
            $this->load->view('general/footer');
        } else{
            redirect('login');
        }
    }
    public function getFamily(){
        if ($this->input->is_ajax_request() && $this->isLogin()) {
             $user_id= $this->input->post('user_id');
            $data['family_member'] = $this->Admin_model->getFamilyMembers('users', array('user_id' => $user_id));
            $this->load->view('body/family-option',$data);
        }
    }
    public function calculateBalance(){
        if ($this->input->is_ajax_request() && $this->isLogin()) {
            $balance = trim($this->input->post('balance'));
            $service_list = print_r($this->input->post('service_list')) ;
          //  $result = $this->Admin_model->getPrice($service_list);
            echo json_encode(array('status' => true, 'balances' => $service_list));
        }
    }
    public function loginToSaloonSoftware(){

            $this->form_validation->set_rules('username', 'Email', 'trim|required|xss_clean');
            $this->form_validation->set_rules('password', 'Password', 'trim|required|xss_clean');
            if($this->form_validation->run() == TRUE) {
                $result = $this->Admin_model->validateLogin(trim($this->input->post('username')), md5(trim($this->input->post('password'))));
              //  print_r($result); exit;
                if( $result !=false ) {
                    $data['user_id'] = $result->user_id;
                    $data['name'] = $result->name;
                    $data['user_name'] = $result->user_name;
                    $data['phone'] = $result->phone;
                    $data['user_role'] = $result->user_role;
                    $data['logged_in'] = true;
                    $this->session->set_userdata($data);
                    if($result->user_role ==0){
                        redirect('my-profile');
                    } else{
                        redirect('dashboard');
                    }

                }else{
                    $this->session->set_flashdata('success','Authentication fail !');
                }
            }
            $this->load->view('body/login');
    }
    public function myPersonalProfile(){
        if($this->session->userdata('logged_in') == true){

            $data['user_info'] = $this->Admin_model->getDataActiveClientById($this->session->userdata('user_id'));
            $data['services'] = $this->Admin_model->getDataServiceByIdNew($this->session->userdata('user_id'));
            // clients_avail_service

            $data['body']= 'my-profile';
            $data['tab']='profile';
            $this->load->view('general/header');
            $this->load->view('general/left-menu',$data);
            $this->load->view('body/main', $data);
            $this->load->view('general/footer');
        } else{
            redirect('login');
        }
    }
    public function userDetails($user_id){
        if($this->session->userdata('logged_in') == true){

            $data['user_info'] = $this->Admin_model->getDataActiveClientByIdAll($user_id);
            $data['services'] = $this->Admin_model->getDataServiceByIdNew($user_id);
           $data['admin'] = true;

            $data['body']= 'my-profile';
            $data['tab']='profile';
            $this->load->view('general/header');
            $this->load->view('general/left-menu',$data);
            $this->load->view('body/main', $data);
            $this->load->view('general/footer');
        } else{
            redirect('login');
        }
    }

    public function allUsers(){
        if($this->isLogin()){
            $data['all_users'] = $this->Admin_model->getDataALl();
           // print_r( $data['all_users']); exit;
            $data['body']= 'all-users';
            $data['tab']='userslist';
            $this->load->view('general/header');
            $this->load->view('general/left-menu',$data);
            $this->load->view('body/main', $data);
            $this->load->view('general/footer');
        } else{
            redirect('login');
        }
    }
    public function clientManage(){
        if ($this->input->is_ajax_request()) {
            $user_id=$this->input->post('u_id');
            $action=$this->input->post('optn');
            // $info=$this->input->post('information');
            $where=array('user_id'=>$user_id);

            if($action == 'active'){
                $data=array('user_status'=>1);
                $this->Admin_model->updateInfo('users',$where,$data);

            } elseif($action == 'deactive'){
                $data=array('user_status'=>0);
                $this->Admin_model->updateInfo('users',$where,$data);
            } elseif($action == 'delete'){
                $this->Admin_model->deleteData('users',$where);
            }
            elseif($action == 'edit'){

            }
            echo json_encode(array('pass' => 'success'));
        } else {
            echo json_encode(array('pass' => 'error'));
        }
    }
    
    public function changePassworRequest(){
        if($this->isLogin()){
            //  $this->load->view('body/dashboard');
            $this->form_validation->set_rules('old_password', 'password', 'trim|required|xss_clean');
            $this->form_validation->set_rules('new_password', 'pew password', 'trim|required|xss_clean');
            $this->form_validation->set_rules('re_password', 'confirm password', 'trim|required|xss_clean|matches[new_password]');
            if ($this->form_validation->run()) {
                $user_id=$this->session->userdata('user_id');

                $check_password=$this->Admin_model->checkPassword('users', array('user_id' =>$user_id ,'password' => md5(trim($this->input->post('old_password')))));
                if($check_password == true){
                    $data=array(
                        'password' => md5(trim($this->input->post('re_password')))
                    );
                    $result = $this->Admin_model->updateInfo('users',array('user_id' =>$user_id ),$data);
                   // echo $this->db->last_query(); exit;
                    if($result == true) {
                        // $this->sendEmail($this->input->post('email'), $data,'email/email-notification');
                        $this->session->set_flashdata('success','Password successfully changed.');
                        redirect('change-password');
                    }
                } else{
                    $this->session->set_flashdata('fail','Existing password does not match ');
                    redirect('change-password');
                }

            }

            $data['body']= 'change-password';
             $data['tab']='';
            $this->load->view('general/header');
            $this->load->view('general/left-menu',$data);
            $this->load->view('body/main', $data);
            $this->load->view('general/footer');
        } else{
            redirect('login');
        }
    }
    public function clientUpdate(){
        if ($this->input->is_ajax_request()) {

            $package_details=$this->Admin_model->getUserData('package_tbl',array('package_id'=>$this->input->post('packages')));
            //print_r($package_details); exit;
            $reg_time=date('Y-m-d');

            $date = date("Y-m-d");
            $month = $package_details->package_period;
            $expire_on = strtotime(date("Y-m-d", strtotime($date)) . " +".$month." month");
            $expire_on = date("Y-m-d",$expire_on);

            $password = trim($this->input->post('password'));
            if($password !='' && !empty($password)){
                $data=array(
                    'name'=>$this->input->post('name'),
                    'user_name'=>$this->input->post('email'),
                    'phone'=>$this->input->post('phone'),
                    'password'=>md5($this->input->post('password')),
                    'package_id' => $this->input->post('packages'),
                    'client_balance' =>$package_details->package_price ,
                    'bonus' => $package_details->bonus,
                    'family_members' =>  $this->input->post('family_members'),
                    'user_status'=>1,
                    'expire_on' =>$expire_on
                );
            } else{
                $data=array(
                    'name'=>$this->input->post('name'),
                    'user_name'=>$this->input->post('email'),
                    'phone'=>$this->input->post('phone'),
                    'package_id' => $this->input->post('packages'),
                    'client_balance' =>$package_details->package_price ,
                    'bonus' => $package_details->bonus,
                    'family_members' =>  $this->input->post('family_members'),
                    'user_status'=>1,
                    'expire_on' =>$expire_on
                );
            }

            $where=array('user_id'=>$this->input->post('u_id'));
            $updated = $this->Admin_model->updateInfo('users',$where,$data);
             echo json_encode(array('status'=>$updated));
        }
    }

    public function clientInformation(){
        if ($this->input->is_ajax_request()) {
            $where=array('user_id' => $this->input->post('u_id'));
            $data['user_info'] = $this->Admin_model->getUserData('users', $where);
            $data['all_package']=$this->Admin_model->getData('package_tbl','','','');
           // $body =  $this->load->view('body/edit-client-modal', $data);
             $this->load->view('body/edit-client-modal', $data);
        }
    }
    public function viewClientInformation(){
        if ($this->input->is_ajax_request()) {
           // $where=array('user_id' => $this->input->post('u_id'));
            $data['user_info'] = $this->Admin_model->getDataActiveClientById($this->input->post('u_id'));
            $this->load->view('body/view-client-modal', $data);
        }
    }
    public function viewServiceTakenInformation(){
        if ($this->input->is_ajax_request()) {
            // $where=array('user_id' => $this->input->post('u_id'));
            // $data['service_taken_info'] = $this->Admin_model->serviceTakenClient($this->input->post('service_id'));
            $data['service_taken_info'] = $this->Admin_model->serviceTakenClientNew($this->input->post('service_id'));

            $this->load->view('body/service-taken-modal', $data);
        }
    }
    public function packageDelete(){
          if ($this->input->is_ajax_request()) {
            // $where=array('user_id' => $this->input->post('u_id'));
             $this->Admin_model->deleteData('package_tbl',array( 'package_id' => $this->input->post('package_id')));
            $data['all_packages']=$this->Admin_model->getData('package_tbl', array('status' => 1),'','');
            $this->load->view('body/package-table-body', $data);
        }
    }
    public function serviceDelete(){
        if ($this->input->is_ajax_request()) {
            // $where=array('user_id' => $this->input->post('u_id'));
             $this->Admin_model->deleteData('service_tbl',array('service_id' => $this->input->post('service_id')));
            $data['services']=$this->Admin_model->getData('service_tbl', array('status' => 1),'','');
            $this->load->view('body/service-table', $data);
        }
    }
    public function updateTable(){
        if ($this->input->is_ajax_request()) {
            if($this->input->post('tbl') == 'users'){
                $data['all_users'] = $this->Admin_model->getDataALl();
                $this->load->view('body/client-table', $data);
            } elseif($this->input->post('tbl') == 'package_tbl'){
                $data['all_packages']=$this->Admin_model->getData('package_tbl', array('status' => 1),'','');
                $this->load->view('body/package-table', $data);
            } elseif($this->input->post('tbl') == 'service_tbl'){
                 $data['services']=$this->Admin_model->getData('service_tbl', array('status' => 1),'','');
                $this->load->view('body/service-table', $data);
            }

        }

    }
    public function getPackageInfo(){
        if ($this->input->is_ajax_request()) {
            $data['package_info']=$this->Admin_model->getUserData('package_tbl',array('package_id' => $this->input->post('package_id')));
            $this->load->view('body/edit-package', $data);
        }
    }
    public function getServiceInfo(){
         if ($this->input->is_ajax_request()) {
            $data['service_info']=$this->Admin_model->getUserData('service_tbl',array('service_id' => $this->input->post('service_id')));
            $this->load->view('body/edit-service', $data);
        }
    }
    public function packageUpdate(){
        if ($this->input->is_ajax_request()){
        $data=array(
            'package_name'=>trim($this->input->post('package_name')),
            'package_price'=>trim($this->input->post('package_price')),
            'package_period' => trim($this->input->post('package_period')),
            'bonus' => trim($this->input->post('bonus'))
        );
        $where=array('package_id'=>$this->input->post('package_id'));
        $updated = $this->Admin_model->updateInfo('package_tbl',$where,$data);
        echo json_encode(array('message' => $updated));
        }
    }
    public function serviceUpdate(){
           if ($this->input->is_ajax_request()){
        $data=array(
            'service_name'=>trim($this->input->post('service_name')),
            'service_price'=>trim($this->input->post('service_price')));
            
        $where=array('service_id'=>$this->input->post('service_id'));
        $updated = $this->Admin_model->updateInfo('service_tbl',$where,$data);
        echo json_encode(array('message' => $updated));
        }
    }

    public function login(){
        if($this->isLogin()){
            redirect();
        } else{
            $this->form_validation->set_rules('username', 'Email', 'trim|required|xss_clean');
            $this->form_validation->set_rules('password', 'Passwrod', 'trim|required|xss_clean');
            if($this->form_validation->run() == TRUE) {
                $result = $this->Admin_model->validateLogin($this->input->post('username'), md5($this->input->post('password')));
                if($result) {
                    $data['user_id'] = $result->user_id;
                    $data['name'] = $result->name;
                    $data['user_name'] = $result->user_name;
                    $data['phone'] = $result->phone;
                    $data['user_role'] = $result->user_role;
                    $data['logged_in'] = true;
                    $this->session->set_userdata($data);
                    redirect('admin');
                }else{
                    $this->session->set_flashdata('success','Registration successful');
                }
            }
            $this->load->view('body/login');
        }

    }
     public function logout(){        // Common pages
        $all=array('user_id','name','user_name','phone','user_role','logged_in');
        $this->session->set_userdata($all);

        $this->session->sess_destroy();
        redirect('login', 'refresh');
    }
    

} 