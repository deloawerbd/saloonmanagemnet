<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class email_support extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model(array('email_support_model'));
    }

    public function add_email_support() {
        $this->form_validation->set_rules('product', 'Product', 'trim|required');
        $this->form_validation->set_rules('category', 'Category', 'trim');
        $this->form_validation->set_rules('options', 'Options', 'trim|required');
        $this->form_validation->set_rules('title', 'Title', 'trim');
        $this->form_validation->set_rules('first_name', 'First Name', 'trim|xss_clean|required|min_length[3]|max_length[20]');
        $this->form_validation->set_rules('last_name', 'Last Name', 'trim|xss_clean|required|min_length[3]|max_length[20]');
        $this->form_validation->set_rules('company', 'Company', 'trim|xss_clean|min_length[2]|max_length[50]');
        $this->form_validation->set_rules('zip_code', 'Zip Code', 'trim|xss_clean|max_length[6]');
        $this->form_validation->set_rules('city', 'City', 'trim|xss_clean|min_length[2]|max_length[20]');
        $this->form_validation->set_rules('country', 'Country', 'trim|xss_clean|required|min_length[2]|max_length[30]');
        $this->form_validation->set_rules('phone_number', 'Phone Number', 'trim|xss_clean|required');
        $this->form_validation->set_rules('fax_number', 'Fax', 'trim|xss_clean');
        $this->form_validation->set_rules('email', 'Email Address', 'trim|xss_clean|required|valid_email');
        $this->form_validation->set_rules('question', 'Question', 'trim|xss_clean|required');

        if ($this->form_validation->run() == FALSE) {
            $data['title'] = 'Email Support';
            $data['view'] = 'external/email_center';
            $this->load->view('external/general/general_body', $data);
        } else {
            $data = array(
                'product' => $this->input->post('product'),
                'category' => $this->input->post('category'),
                'options' => $this->input->post('options'),
                'title' => $this->input->post('title'),
                'first_name' => $this->input->post('first_name'),
                'last_name' => $this->input->post('last_name'),
                'company' => $this->input->post('company'),
                'zip_code' => $this->input->post('zip_code'),
                'city' => $this->input->post('city'),
                'country' => $this->input->post('country'),
                'phone_number' => $this->input->post('phone_number'),
                'fax_number' => $this->input->post('fax_number'),
                'email' => $this->input->post('email'),
                'question' => $this->input->post('question'),
            );
            if ($this->session->userdata('logged_in')) {
                $this->email_support_model->support_insert($data);
            } else {
                $this->email_support_model->support_insert_non_user($data);
            }

            $data['message'] = 'Message has been sent successfully!';
            $data['title'] = 'Email Support';
            $data['view'] = 'external/email_center';
            $this->load->view('external/general/general_body', $data);
        }
    }

    public function web_hosting_view(){
        $data['email_supports'] = $this->email_support_model->get_email_support('Web Hosting');
        #Breadcrumb
        $this->breadcrumbs->push('Email Support', '/admin');
        $this->breadcrumbs->push('Web Hosting', '/email_support/web_hosting');
        $this->breadcrumbs->unshift('Admin', '/');
        $data['title'] = 'Email Support - Web Hosting';
        $data['view'] = 'internal/email_support_view';
        $this->load->view('internal/general/general_body', $data);
    }

    public function vps_server_view(){
        $data['email_supports'] = $this->email_support_model->get_email_support('VPS Server');
        #Breadcrumb
        $this->breadcrumbs->push('Email Support', '/admin');
        $this->breadcrumbs->push('VPS Server', '/email_support/vps_server_view');
        $this->breadcrumbs->unshift('Admin', '/');
        $data['title'] = 'Email Support - VPS Server';
        $data['view'] = 'internal/email_support_view';
        $this->load->view('internal/general/general_body', $data);
    }

    public function dedicated_server_view(){
        $data['email_supports'] = $this->email_support_model->get_email_support('Dedicated Server');
        #Breadcrumb
        $this->breadcrumbs->push('Email Support', '/admin');
        $this->breadcrumbs->push('Dedicated Server', '/email_support/dedicated_server_view');
        $this->breadcrumbs->unshift('Admin', '/');
        $data['title'] = 'Email Support - Dedicated Server';
        $data['view'] = 'internal/email_support_view';
        $this->load->view('internal/general/general_body', $data);
    }

    public function dns_hosting_view(){
        $data['email_supports'] = $this->email_support_model->get_email_support('DNS Server');
        #Breadcrumb
        $this->breadcrumbs->push('Email Support', '/admin');
        $this->breadcrumbs->push('DNS Hosting', '/email_support/dns_hosting_view');
        $this->breadcrumbs->unshift('Admin', '/');
        $data['title'] = 'Email Support - DNS Hosting';
        $data['view'] = 'internal/email_support_view';
        $this->load->view('internal/general/general_body', $data);
    }

    public function vpn_account_view(){
        $data['email_supports'] = $this->email_support_model->get_email_support('VPN Connection');
        #Breadcrumb
        $this->breadcrumbs->push('Email Support', '/admin');
        $this->breadcrumbs->push('VPN Account', '/email_support/vpn_account_view');
        $this->breadcrumbs->unshift('Admin', '/');
        $data['title'] = 'Email Support - VPN Account';
        $data['view'] = 'internal/email_support_view';
        $this->load->view('internal/general/general_body', $data);
    }

    public function whois_view(){
        $data['email_supports'] = $this->email_support_model->get_email_support('Free WhoIs');
        #Breadcrumb
        $this->breadcrumbs->push('Email Support', '/admin');
        $this->breadcrumbs->push('Whois Database', '/email_support/whois_view');
        $this->breadcrumbs->unshift('Admin', '/');
        $data['title'] = 'Email Support - Whois Database';
        $data['view'] = 'internal/email_support_view';
        $this->load->view('internal/general/general_body', $data);
    }

    public function specificDataToShow(){
        $data['information'] = $this->email_support_model->getData('email_support', 'id', $this->input->post('id'));
        $this->email_support_model->updateStatus('email_support', $this->input->post('id'));
        $this->load->view('internal/email-support-modal', $data);
    }

    public function send_mail() {
        $config['protocol'] = 'smtp';
        $config['smtp_host'] = 'ssl://smtp.gmail.com';
        $config['smtp_port'] = 465;
        $config['smtp_user'] = 'whpp.project@gmail.com';
        $config['mailpath'] = "/usr/bin/sendmail";
        $config['smtp_pass'] = 'whpp12345678';
        $config['mailtype'] = 'html';
        $config['charset'] = 'iso-8859-1';
        $config['wordwrap'] = TRUE;
        $config['newline'] = "\r\n";
        $this->email->initialize($config);
        $from_email = "whpp.project@gmail.com";
        $email = $this->input->post('email');
        $reply = $this->input->post('reply');
        $this->email->from($from_email, 'NetaHost');
        $this->email->to($email);
        $this->email->subject('Inquiries');
        $this->email->message($reply);
        #Send Mail 
        if($this->email->send()){
            $this->session->set_flashdata("email_sent", "Email sent successfully.");
        }else{
            $this->session->set_flashdata("email_sent", "Error in sending Email.");
        }
        $this->load->view('internal/email_support_view');
    }

}
