<?php 
	class Admin_model extends CI_Model{
		
		 public function getData($table, $where=null,$order_by=null,$sequence){
			    $this->db->select('*');
				
				 if($order_by !=null){
					  $this->db->order_by($order_by,$sequence);
					 }	
					 
				 if($where !=null){
					 $result=$this->db->get_where($table,$where);
					}else{
					  $result=$this->db->get($table);
					}
				
				if($result->num_rows()>0){
					 return $result->result();
					} else{
					  return false;
					}	
					
			 }
        public function getDataRow($table, $where){
              $this->db->select('user_id, name, phone');
            $result= $this->db->get_where($table, $where);
            if($result->num_rows() >0 ){
               return $result->row();
            } else{
                return false;
            }
        }
        public function getDataALl(){
            $this->db->select('users.*, package_tbl.package_name, (users.client_balance + users.bonus) total_balance, ((users.client_balance + users.bonus)-current_balance) cost');
            $this->db->join('package_tbl','package_tbl.package_id =users.package_id', 'left');
            $this->db->where('users.user_role !=', 1);
            $result=$this->db->get('users');
            return ($result->num_rows()>0) ? $result->result() : false;
        }
        public function getDataActiveClient(){
            $this->db->select('package_tbl.package_name, users.user_id, users.client_balance, users.name, users.bonus, users.current_balance, (users.client_balance + users.bonus) total_balance, ((users.client_balance + users.bonus)-current_balance) cost');
            $this->db->join('package_tbl','package_tbl.package_id=users.package_id','left');
            $this->db->where('users.user_status', 1);
            $this->db->where('users.user_role !=', 1 );
            $result=$this->db->get('users');
            return $result->result();
        }
        public function getDataActiveClientAll(){
            $this->db->select('package_tbl.package_name, users.*');
            $this->db->join('package_tbl','package_tbl.package_id=users.package_id','left');
            $this->db->where('users.user_role !=', 1);
            $result=$this->db->get('users');
            return $result->result();
        }
        public function getDatatakenServices(){
            $this->db->select('service_tbl.service_name, users.name, clients_avail_service.id as servicetaken_id,  clients_avail_service.price as avail_price, clients_avail_service.date as avail_date');
            $this->db->join('service_tbl','clients_avail_service.service_id=service_tbl.service_id','left');
            $this->db->join('users','users.user_id=clients_avail_service.user_id','left');
            $result=$this->db->get('clients_avail_service');
            return $result->result();
        }

        public function getDatatakenServicesNew(){
            $this->db->select('clients_avail_service.service_id service_name, clients_avail_service.family_members as taker, users.name, clients_avail_service.id as servicetaken_id,  clients_avail_service.price as avail_price, clients_avail_service.date as avail_date');
            $this->db->join('service_tbl','clients_avail_service.service_id=service_tbl.service_id','left');
            $this->db->join('users','users.user_id=clients_avail_service.user_id','left');
            $result=$this->db->get('clients_avail_service');
            return $result->result();
        }

        public function checkBalance($user_id, $amount){
            $balance = $this->db->select('current_balance, name')->get_where('users',array('user_id' => $user_id, 'current_balance >=' => $amount));
           // $result = $this->db->select('*')->get_where('service_tbl', array('service_price <=' => $balance->current_balance));
            return ( $balance->num_rows() > 0) ? $balance->row() : false;
        }
        public function getPackageName($table, $list){
           $res = $this->db->select('service_name')->where_in('service_id',$list)->get($table);
            return ( $res->num_rows() > 0) ? $res->result() : false;
        }


        public function serviceTakenClient($service_id){
            $this->db->select('service_tbl.service_name, users.*, clients_avail_service.price as avail_price, clients_avail_service.date as avail_date');
            $this->db->join('service_tbl','clients_avail_service.service_id=service_tbl.service_id','left');
            $this->db->join('users','users.user_id=clients_avail_service.user_id','left');
            $this->db->where('clients_avail_service.id', $service_id);
            $result=$this->db->get('clients_avail_service');
            return $result->row();
        }
        public function serviceTakenClientNew($service_id){
            $this->db->select('clients_avail_service.service_id service_name, clients_avail_service.family_members taken, users.*, clients_avail_service.price as avail_price, clients_avail_service.date as avail_date');
            $this->db->join('users','users.user_id=clients_avail_service.user_id','left');
            $this->db->where('clients_avail_service.id', $service_id);
            $result=$this->db->get('clients_avail_service');
            return $result->row();
        }

        public function getDataActiveClientById($id){
            $this->db->select('package_tbl.package_name, users.*, (users.client_balance + users.bonus) total_balance, ((users.client_balance + users.bonus)-current_balance) cost');
            $this->db->join('package_tbl','package_tbl.package_id=users.package_id','left');
            $this->db->where(array('users.user_status' =>1, 'users.user_id'=>$id ));
            $result=$this->db->get('users');
            return $result->row();
        }
        public function getDataActiveClientByIdAll($id){
            $this->db->select('package_tbl.package_name, users.*, (users.client_balance + users.bonus) total_balance, ((users.client_balance + users.bonus)-current_balance) cost');
            $this->db->join('package_tbl','package_tbl.package_id=users.package_id','left');
            $this->db->where(array('users.user_id'=>$id ));
            $result=$this->db->get('users');
            return $result->row();
        }

        public function getDataServiceById($id){
            $this->db->select('service_tbl.service_name, users.*, clients_avail_service.price as avail_price, clients_avail_service.date as avail_date, clients_avail_service.remark invoice');
            $this->db->join('service_tbl','clients_avail_service.service_id=service_tbl.service_id','left');
            $this->db->join('users','users.user_id=clients_avail_service.user_id','left');
            $this->db->where(array('clients_avail_service.user_id' =>$id));
            $result=$this->db->get('clients_avail_service');
            return $result->result();
        }
        public function getDataServiceByIdNew($id){
            $this->db->select('clients_avail_service.service_id service_name, clients_avail_service.family_members taker, clients_avail_service.remark invoice , users.*, clients_avail_service.price as avail_price, clients_avail_service.date as avail_date');
            $this->db->join('users','users.user_id=clients_avail_service.user_id','left');
            $this->db->where(array('clients_avail_service.user_id' =>$id));
            $result=$this->db->get('clients_avail_service');
            return $result->result();
        }


        public function updateBalance($tbl,$id, $price){
            $query = "UPDATE $tbl SET current_balance = current_balance-$price WHERE user_id=$id";
           $this->db->query($query);
           return ($this->db->affected_rows() > 0)? true:false;

        }

			 
			 public function getUserData($table,$where){
				   $query=$this->db->select('*')->get_where($table,$where);
				   return $query->row();
				}

        public function getFamilyMembers($tbl,$where){
            $query=$this->db->select('family_members, name')->get_where($tbl,$where);
            return $query->row();
        }
        public function getPrice($list){
            $query=$this->db->select('sum(service_price) total_price')->where_in('service_id',$list)->get('service_tbl');
            return ($query->num_rows()>0)? $query->row(): false;
        }
        public function checkPassword($table,$where){
            $query=$this->db->select('*')->get_where($table,$where);
            return ($query->num_rows()>0)?true: false;
        }
			 
			public function getRequestData($table){
				 $this->db->select('all_records.title,requests.*');
				 $this->db->join('all_records','all_records.record_id=requests.property_id','left');
				 $result=$this->db->get($table);
				 if($result->num_rows()>0){
					  return $result->result();
					 } else{
					  return false;
					 }
			} 
				
		 public function getPropertyData($table){
		      $query=$this->db->select('all_records.*, city.city_name')
					->join('city','city.city_id=all_records.city_id','left')
					->order_by('record_id','DESC')
					->get($table);
				if($query->num_rows()>0){
					  return $query->result();
					} else{
					   return false;
					}	
			 
			 }
			 
			 public function dataInsert($table,$info){
				  $this->db->insert($table,$info);
				  if($this->db->affected_rows()>0){
					    return $this->db->insert_id();
					  } else{
					   return false;
					  }
				 } 
			public function checkEmail($table,$where,$value){
				 $query=$this->db->get_where($table,array($where=>$value));
				 return $query->num_rows()>0;
				}	
				
			public function updateInfo($table,$where,$info){
				 $this->db->where($where)->update($table,$info);
				return ($this->db->affected_rows()>0)?true:false;
				}	
			public function deleteData($table,$where){
				 $this->db->delete($table,$where);
				 return $this->db->affected_rows()>0;
				}	
				
			function validateLogin($username,$password) {
				   $this-> db -> select('*');
				   $this-> db -> from('users');
				   $this-> db -> where('user_name', $username);
				   $this-> db -> where('password', $password);
				   $this-> db -> where('user_status', 1);
				   $query = $this -> db -> get();
				 //  echo $this->db->last_query(); exit;
                return ($query->num_rows() > 0) ? $query->row(): false;
					//return $query->row();
				
			}	
			
			public function getAllLogiInfo($table){
			   $result=$this->db->select('user_login_table.*,users_tbl.full_name,users_tbl.email')
			   ->join('users_tbl','users_tbl.user_id=user_login_table.user_id','left')
			   ->get($table);
			   return ($result->num_rows()>0)?$result->result():false;
				
				}
				public function checkUserStatus($table,$where){
				 $query=$this->db->get_where($table,$where);
				 return ($query->num_rows()>0)?true:false;
				}

				
				 
		}
	
	
	?>