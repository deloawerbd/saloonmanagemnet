
<!-- Left side column. contains the logo and sidebar -->
<aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
        <!-- Sidebar user panel -->

        <div class="user-panel">
            <div class="pull-left image">
                <img src="<?php echo base_url()?>assets/dist/img/user2-160x160.jpg" class="img-circle" alt="User Image">
            </div>
            <div class="pull-left info">
                <p><?php  echo ($this->session->userdata('user_role')==1) ? 'Admin': $this->session->userdata('name');?></p>
            </div>
        </div>

        <?php
        if($this->session->userdata('user_role')==1){ ?>
        <!-- /.search form -->
        <!-- sidebar menu: : style can be found in sidebar.less -->
        <ul class="sidebar-menu">
            <li class="<?php echo ($tab=='dashboard') ? 'active' : '';?> treeview">
                <a href="<?php echo base_url('dashboard')?>">
                    <i class="fa fa-dashboard"></i> <span>Dashboard</span>
                </a>

            </li>
            <li class="<?php echo ($tab=='package') ? 'active' : '';?> treeview">
                <a href="<?php echo base_url('add-package')?>"><i class="glyphicon glyphicon-pencil"></i> <span>Create Packages </span></a>

            </li>
            <li class=" <?php echo ($tab=='register') ? 'active' : '';?> treeview">
                <a href="<?php echo base_url('add-user')?>"><i class="glyphicon glyphicon-plus"></i><span>Member Registration</span></a>
            </li>

            <li class=" <?php echo ($tab=='userslist') ? 'active' : '';?> treeview">
                <a href="<?php echo base_url('users')?>">
                    <i class="glyphicon glyphicon-user"></i> <span>All Customers</span>
                </a>
            </li>
            <li class=" <?php echo ($tab=='tabel_service') ? 'active' : '';?> treeview"><a href="<?php echo base_url('take-service')?>">  <i class="glyphicon glyphicon-th-list"></i> <span>Avail Service</span></a></li>
            <li class=" <?php echo ($tab=='service') ? 'active' : '';?> treeview"><a href="<?php echo base_url('add-service')?>">  <i class="glyphicon glyphicon-hand-right"></i> <span>Add service</span></a></li>
        <?php } else{ ?>
            <li class=" <?php echo ($tab=='profile') ? 'active' : '';?> treeview"><a href="<?php echo base_url('user-panel')?>"><i class="fa fa-book"></i> <span>Profile</span></a></li>

        <?php }  ?>

        </ul>

    </section>
    <!-- /.sidebar -->
</aside>
