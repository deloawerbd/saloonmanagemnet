<?php
 if($service_taken_info !=false){ ?>
     <div class="modal-header">
         <button type="button" class="close" data-dismiss="modal">&times;</button>
         <h4 class="modal-title">  
         <?php echo trim($service_taken_info->service_name, ',') ;?></h4>
     </div>
     <div class="modal-body">
         <div class="">
             <div class="box-body box-profile">
                 <ul class="list-group list-group-unbordered">
                     <li class="list-group-item">
                         <b>Name : </b> <a class="pull-right"><?php echo $service_taken_info->name ;?></a>
                     </li>
                     <li class="list-group-item">
                         <b>Service Name :</b> <a class="pull-right"><?php echo trim($service_taken_info->service_name, ',') ;?></a>
                     </li>
                     <li class="list-group-item">
                         <b>Service Price :</b> <a class="pull-right"><?php echo $service_taken_info->avail_price ;?></a>
                     </li>
                     <li class="list-group-item">
                         <b>Service Taken on :</b> <a class="pull-right"> <?php echo date_format(date_create($service_taken_info->avail_date),'d-m-Y');?>
                          </a>
                     </li>
                     <li class="list-group-item">
                         <b>Service Taken By :</b> <a class="pull-right"><?php echo trim($service_taken_info->taken, ',') ;?></a>
                     </li>

                 </ul>
             </div>
             <!-- /.box-body -->
         </div>
     </div>
     <div class="modal-footer">

         <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
     </div>
<?php } else { ?>
     <div class="modal-body">
         <div class="">
              No record to show.
         </div>
     </div>
<?php  }?>

