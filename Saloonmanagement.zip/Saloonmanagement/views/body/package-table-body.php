<thead>
<tr>
    <th style="width: 10px">#</th>
    <th>Package Name</th>
    <th>Price</th>
    <th>Period</th>
    <th style="width: 40px">Action</th>
</tr>
</thead>
<tbody>

<?php

if($all_packages !=false){
    $count=0;
    foreach($all_packages as $all_packages){
        $count++;
        ?>
        <tr>
            <td><?php echo $count;?>.</td>
            <td><?php echo $all_packages->package_name ?></td>
            <td>
                <span>₹</span><?php echo $all_packages->package_price ?>
            </td>
            <td>
                <?php echo $all_packages->package_period ?> Months
            </td>
            <td style="width: 25%"><span> <a href="#" onclick="return editOption(<?php echo $all_packages->package_id ?>, 'package' )"><span class="glyphicon glyphicon-pencil"></span></a> |
                                <a href="#" onclick="return deleteOption(<?php echo $all_packages->package_id ?>, 'package' )" ><span class="glyphicon glyphicon-trash"></span></a></span>
            </td>
        </tr>
    <?php } }?>


</tbody>