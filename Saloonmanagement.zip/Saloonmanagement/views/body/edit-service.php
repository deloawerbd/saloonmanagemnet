
    <div class="form-group my-success" style="color: green;font-weight: bold; text-align: center"> </div>

<form action="" method="post" accept-charset="UTF-8" enctype="multipart/form-data" autocomplete="off"  >

  <input type="hidden" name="edited_service_id" id="edited_service_id" value="<?php echo $service_info->service_id;?>">
    <div class="form-group">
        <label>Service Name</label>
        <input type="text" class="form-control pull-right" id ="service_name" name="service_name" value="<?php echo $service_info->service_name;?>" >

    </div>

    <div class="form-group">
        <label>Service Price </label>
        <input type="text" class="form-control pull-right" name="service_price" id="service_price" value="<?php echo $service_info->service_price;?>" >

    </div>

</form>