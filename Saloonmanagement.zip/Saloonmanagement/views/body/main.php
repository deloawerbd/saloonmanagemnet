
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
<!-- Content Header (Page header) -->

<!-- Main content -->
<section class="content">
<?php include($body.'.php')?>

</section>
<!-- /.content -->
</div>
