
<!-- SELECT2 EXAMPLE -->
<div class="box box-default">
    <div class="box-header with-border">
        <h3 class="box-title" style="text-align: center">Change password from here</h3>
    </div>
    <!-- /.box-header -->
    <div class="box-body">
        <div class="row">
            <div class="col-md-2">
                &nbsp;
            </div>
            <div class="col-md-8">
                <?php
                if($this->session->flashdata('success')){ ?>
                    <div class="form-group my-success" style="color: green;font-weight: bold; text-align: center"><?php echo $this->session->flashdata('success');
                     $this->session->unset_userdata('success');
                     ?> </div>
                <?php } elseif($this->session->flashdata('fail')){ ?>
                    <div class="form-group my-success" style="color: red;font-weight: bold; text-align: center"><?php echo $this->session->flashdata('fail'); 
                     $this->session->unset_userdata('fail');
                    ?> </div>
                <?php
                } ?>

                <form action="<?php echo base_url('change-password')?>" method="post" accept-charset="UTF-8" enctype="multipart/form-data" autocomplete="off"  >
                    <div class="form-group">
                        <label>Old Passowd</label>
                        <input type="password" class="form-control pull-right" name="old_password" >
                        <?php echo form_error('old_password', '<div class="adduseradminerror">', '</div>'); ?>
                    </div>

                    <div class="form-group">
                        <label>New Password</label>
                        <input type="password" class="form-control pull-right" name="new_password" >
                        <?php echo form_error('new_password', '<div class="adduseradminerror">', '</div>'); ?>
                    </div>

                    <div class="form-group">
                        <label>Confirm Password</label>
                        <input type="password" class="form-control pull-right" name="re_password" >
                        <?php echo form_error('re_password', '<div class="adduseradminerror">', '</div>'); ?>
                    </div>

                    <div class="form-group ">
                        <label>&nbsp;</label>
                        <button type="submit" class="form-control btn btn-primary pull-right"> Change Password</button>
                    </div>
                <!-- /.form-group -->
                <!-- /.form-group -->
                    </form>
            </div>
            <!-- /.col -->
            <div class="col-md-2">
                &nbsp;
            </div>
            <!-- /.col -->
        </div>
        <!-- /.row -->
    </div>
    <!-- /.box-body -->
    <div class="box-footer">
        &nbsp;
    </div>
</div>
<!-- /.box -->


<script type="text/javascript">
    jQuery(document).ready(function(){

        setTimeout(function(){
            $(".my-success").text(' ');
        },3000);

    });
</script>
