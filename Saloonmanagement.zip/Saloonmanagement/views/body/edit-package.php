
    <div class="form-group my-success" style="color: green;font-weight: bold; text-align: center"> </div>

<form action="" method="post" accept-charset="UTF-8" enctype="multipart/form-data" autocomplete="off"  >

  <input type="hidden" name="edited_package_id" id="edited_package_id" value="<?php echo $package_info->package_id;?>">
    <div class="form-group">
        <label>Package Name</label>
        <input type="text" class="form-control pull-right" id ="package_name" name="package_name" value="<?php echo $package_info->package_name;?>" >

    </div>

    <div class="form-group">
        <label>Package Price </label>
        <input type="text" class="form-control pull-right" name="package_price" id="package_price" value="<?php echo $package_info->package_price;?>" >

    </div>
    <div class="form-group">
        <label>Package Period in months</label>
        <input type="text" class="form-control pull-right" name="package_period" id="package_period" value="<?php echo $package_info->package_period;?>" >
    </div>

    <div class="form-group">
        <label>Benefit / Bonus</label>
        <input type="text" class="form-control pull-right" name="bonus" id="bonus" value="<?php echo $package_info->bonus;?>"  >
    </div>
</form>