
<?php
if($user_info !=false){ ?>
    <div class="">
        <div class="box-body box-profile">
            <img class="profile-user-img img-responsive img-circle" src="<?php echo base_url()?>assets/dist/img/user4-128x128.jpg" alt="User profile picture">

            <h3 class="profile-username text-center">Welcome, <?php echo $user_info->name;?> </h3>
            <p class="text-muted text-center">Member Since <?php echo $user_info->registered_date;?></p>
            <ul class="list-group list-group-unbordered">
                <li class="list-group-item">
                    <b>Email : </b> <a class="pull-right"><?php echo $user_info->user_name;?></a>
                </li>
                <li class="list-group-item">
                    <b>Phone : </b> <a class="pull-right"><?php echo $user_info->phone;?></a>
                </li>
                <li class="list-group-item">
                    <b>Package Taken :</b> <a class="pull-right"><?php echo $user_info->package_name;?></a>
                </li>
                <li class="list-group-item">
                    <b>Available balance :</b> <a class="pull-right">₹ <?php
                        $balance = '';
                        if( $user_info->cost > $user_info->client_balance){
                            $balance= 0;
                        } else{
                            $balance= $user_info->client_balance - $user_info->cost;
                        }
                        echo $balance; ?>
                    </a>
                </li>
                <li class="list-group-item">
                    <b>Benefit balance :</b> <a class="pull-right">₹<?php
                        $bonus_exist = '';
                        if( $user_info->cost > $user_info->client_balance){
                            $bonus_exist = $user_info->bonus - ($user_info->cost - $user_info->client_balance);
                            if($bonus_exist <0){
                                $bonus_exist=0;
                            }
                        } else{
                            $bonus_exist = $user_info->bonus;
                        }
                        echo $bonus_exist;?></a>
                </li>
                <li class="list-group-item">
                    <b>Expire on :</b> <a class="pull-right"> <?php echo $user_info->expire_on;?></a>
                </li>
            </ul>
        </div>
        <!-- /.box-body -->
    </div>
<?php  } else{ ?>
    <div class="form-group">
        No record to show
    </div>
<?php } ?>
