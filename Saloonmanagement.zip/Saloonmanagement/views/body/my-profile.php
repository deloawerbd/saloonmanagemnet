
<div class="row">
<div class="col-md-4">
    <!-- Profile Image -->
       <!-- /.box -->
    <div class="box box-primary">
        <div class="box-body box-profile">
            <img class="profile-user-img img-responsive img-circle" src="<?php echo base_url()?>assets/dist/img/user4-128x128.jpg" alt="User profile picture">

            <h3 class="profile-username text-center">
                <?php if(isset($admin) && $admin==true){echo '';} else{ echo 'Welcome, ';}?>
                <?php echo ($user_info->name !='' || $user_info->name != null)? $user_info->name : ''?> </h3>

            <ul class="list-group list-group-unbordered">
                <li class="list-group-item">
                    <b>Email : </b> <a class="pull-right"><?php echo ($user_info->user_name !='' || $user_info->user_name != null)? $user_info->user_name : ''?></a>
                </li>
                <!--<li class="list-group-item">-->
                <!--    <b>Phone : </b> <a class="pull-right">+990372763</a>-->
                <!--</li>-->
                <li class="list-group-item">
                    <b>Package Name :</b> <a class="pull-right"><?php echo ($user_info->package_name !='' || $user_info->package_name != null)? $user_info->package_name : ''?></a>
                </li>
                <li class="list-group-item">
                    <b>Available balance :</b> <a class="pull-right"> <span>₹</span>
                        <?php
                        /*
                        $balance = '';
                        if( $user_info->cost > $user_info->client_balance){
                            $balance= 0;
                        } else{
                            $balance= $user_info->client_balance - $user_info->cost;
                        }
                        */
                        echo  $user_info->current_balance;
                        // echo $balance;

                        ?>
                    </a>
                </li>
                <li class="list-group-item">
                    <b>Benefit balance :</b> <a class="pull-right"><span>₹</span>
                        <?php
                        $bonus_exist = '';
                        if( $user_info->cost > $user_info->client_balance){
                            $bonus_exist = $user_info->bonus - ($user_info->cost - $user_info->client_balance);
                            if($bonus_exist <0){
                                $bonus_exist=0;
                            }
                        } else{
                            $bonus_exist = $user_info->bonus;
                        }
                        echo $bonus_exist;?></a>
                </li>
                <li class="list-group-item">
                    <b>Registration date : </b> <a class="pull-right">
                        <?php echo date_format(date_create($user_info->registered_date),'d-m-Y');?>
                        </a>
                </li>
                <li class="list-group-item">
                    <b>Expire on : </b> <a class="pull-right">
                        <?php echo date_format(date_create($user_info->expire_on),'d-m-Y');?>
                        </a>
                </li>
                <li class="list-group-item">
                    <b>Family Members : </b>

                        <?php
                        if($user_info->family_members !='' || $user_info->family_members !=null){
                            $family_members = explode(',', $user_info->family_members);
                        }
                        for($i=0 ;$i<count($family_members); $i++){ ?>
                             <a class="pull-right"><?php echo ucfirst(trim($family_members[$i])); ?> </a> <br>
                        <?php }  ?>


                </li>


            </ul>
        </div>
        <!-- /.box-body -->
    </div>

    <!-- /.box -->
</div>
<!-- /.col -->
<div class="col-md-8">
    <div class="box">
        <div class="box-header">
            <h3 class="box-title">Service Avail </h3>
        </div>
        <!-- /.box-header -->
        <div class="box-body no-padding">
            <table class="table table-condensed" id="service_taken">
               <thead>
                <tr>
                    <th style="width: 10px">#</th>
                    <th>Service Name</th>
                    <th>Taker Name</th>
                    <th>Price</th>
                    <th>Reference No</th>
                    <th style="width: 25%">Service Avail Date</th>
                </tr>
               </thead>
                <tbody>
                    <?php
                    $count=0;
                    if($services !=false){
                        foreach($services as $services){
                            $count++ ;
                            ?>
                            <tr>
                                <td><?php echo $count;?>.</td>
                                <td><?php echo trim($services->service_name,',') ?></td>
                                <td> <?php echo trim($services->taker, ',') ?></td>
                                <td><span>₹</span><?php echo $services->avail_price; ?></td>
                                <th><?php echo ($services->invoice !='' && $services->invoice !=null) ? $services->invoice:'NA'; ?></th>
                                <td style="width: 33%"> <?php echo date("D, d M Y H:i:s a", strtotime($services->avail_date)) ;?></td>
                            </tr>
                    <?php } } ?>

                </tbody>

            </table>
        </div>

    </div>
<!-- /.nav-tabs-custom -->
</div>
<!-- /.col -->
</div>
<!-- /.row -->
<script type="text/javascript">
    $(document).ready(function() {
        // if ( ! $.fn.DataTable.isDataTable( '#client_table' ) ) {
        $('#service_taken').dataTable({
            "ordering": true,
            "lengthChange": false,
            "searching": false,
            "pageLength": 15,
            "order": [[ 0, "desc" ]],
            "info":     false
        });
        // }
    } );
</script>
