<thead>
<tr>
    <th style="width: 10px">#</th>
    <th>Name </th>
    <th>Phone</th>
    <th>Family Members</th>
    <th>Registered Date</th>
    <th>Expiry Date</th>
    <th>Available Balance</th>
    <th>Profile</th>
    <th style="width: 40px">Status</th>
    <th>Action</th>
</tr>
</thead>
<tbody>
<?php
$count=0;
if($all_users !=false){
    foreach($all_users as $all_users){
        $count++;
        ?>
        <tr>
            <td><?php echo $count;?></td>
            <td><?php echo $all_users->name;?></td>
            <td><?php echo $all_users->phone;?></td>
            <td><?php echo trim($all_users->family_members,',');?></td>
            <td> <?php echo date_format(date_create($all_users->registered_date),'d-m-Y');?> </td>
            <td> <?php echo date_format(date_create($all_users->expire_on),'d-m-Y');?></td>
            <td><?php
                $balance = '';
                if( $all_users->cost > $all_users->client_balance){
                    $balance= 0;
                } else{
                    $balance= $all_users->client_balance - $all_users->cost;
                }
                echo $balance; ?>
            </td>
            <td> <a target="_blank" href="<?php echo base_url('user-details/'.$all_users->user_id)?>">Profile</a> </td>
            <td> <span class="label <?php echo ($all_users->user_status == 0)?'label-warning':'label-success';?> "> <?php echo ($all_users->user_status == 0)?'Inactive':'Active';?> </span> </td>
            <td style="width: 10%"><span>
                                     <a href="#" onclick="return Client(<?php echo $all_users->user_id;?>, 'edit')"> <span class="glyphicon glyphicon-pencil"></span></a> |
                    <?php if ($all_users->user_status == 0){ ?>
                        <a href="#" onclick="return Client(<?php echo $all_users->user_id;?>, 'active')" ><span class="glyphicon glyphicon-ok"></span></a> |
                    <?php } else{ ?>
                        <a href="#" onclick="return Client(<?php echo $all_users->user_id;?>, 'deactive')"  ><span class="glyphicon glyphicon-ban-circle"></span></a> |
                    <?php }?>

                    <a href="#" onclick="return Client(<?php echo $all_users->user_id;?>, 'delete')"  ><span class="glyphicon glyphicon-trash"></span></a>
                                 </span>
            </td>
        </tr>
    <?php }} else{ ?>
    <tr>
        <td colspan="8"> No users yet</td>
    </tr>
<?php }
?>
</tbody>
