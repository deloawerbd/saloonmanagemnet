
<div class="row">
<div class="col-md-6">
    <div class="box">
        <div class="box-header with-border">
            <h3 class="box-title"> <span class="glyphicon glyphicon-user"></span> &nbsp;Active clients</h3>
            <a href="<?php echo base_url('add-user')?>" class="pull-right btn btn-default btn-sm"> <span class="glyphicon glyphicon-plus"></span> Add new client </a>
        </div>
        <!-- /.box-header -->
        <div class="box-body">
            <table class="table table-bordered" id="active_client_table">
                <thead>
                <tr>
                    <th style="width: 10px">#</th>
                    <th>Name</th>
                    <th>Package</th>
                    <th style="">Available balance</th>
                    <th style="">Details</th>
                </tr>
                </thead>
                <tbody>
                <?php
                $count=0;
                if($all_users !=false){
                foreach($all_users as $all_users){

                $count++;
                ?>
                <tr>
                    <td> <?php echo $count;?>.</td>
                    <td><?php echo $all_users->name; ?></td>
                    <td><?php echo $all_users->package_name; ?></td>
                    <td>
                        <?php
                        $balance = '';
                        if( $all_users->cost > $all_users->client_balance){
                            $balance= 0;
                        } else{
                            $balance= $all_users->client_balance - $all_users->cost;
                        }
                        echo '₹'.$balance;

                        ?>
                    </td>
                    <td><a href="#" onclick="return Client(<?php echo $all_users->user_id;?>, 'view')" >Details</a></td>
                </tr>
                <?php } }?>
                </tbody>

            </table>
        </div>
    </div>
    <!-- /.box -->


</div>
<!-- /.col -->
<div class="col-md-6">
    <div class="box">
        <div class="box-header">
            <h3 class="box-title"> <span class="glyphicon glyphicon-user"></span> &nbsp;All Clients</h3>
        </div>
        <!-- /.box-header -->
        <div class="box-body no-padding">
            <table class="table table-condensed" id="all_client_table">
                <thead>
                <tr>
                    <th style="width: 10px">#</th>
                    <th>Clients Name</th>
                    <th>Email</th>
                    <th style="width: 40px">Status</th>
                    <th style="">Details</th>
                </tr>
                </thead>
                <tbody>


                <?php
                $count=0;
                if($all_users_ac !=false){
                    foreach($all_users_ac as $all_users_ac){
                        $count++;
                        ?>
                        <tr>
                            <td> <?php echo $count;?>.</td>
                            <td><?php echo $all_users_ac->name ?></td>
                            <td><?php echo $all_users_ac->user_name ?></td>
                            <td> <span class="label  <?php echo ($all_users_ac->user_status ==0)?'label-warning':'label-success'; ?>"><?php echo ($all_users_ac->user_status ==0)?'Inactive':'Active'; ?> </span> </td>
                            <td><a href="#" onclick="return Client(<?php echo $all_users_ac->user_id;?>, 'view')" >Details</a></td>
                        </tr>

                    <?php } }?>
            </table>
            </tbody>

        </div>

        <!-- /.box-body -->
    </div>
    <!-- /.box -->
    <!-- /.box -->
</div>
<!-- /.col -->
</div>
<!-- /.row -->

<div class="row">
<div class="col-md-6">
    <div class="box">
        <div class="box-header">
            <h3 class="box-title"> <span class="glyphicon glyphicon-hand-down"></span>&nbsp;Our Services</h3>
            <a href="<?php echo base_url('add-service')?>" class="pull-right btn btn-default btn-sm"> <span class="glyphicon glyphicon-plus"></span> Add new Service </a>
        </div>
        <!-- /.box-header -->
        <div class="box-body no-padding">

            <table class="table table-striped" id="service_list_table">
                <thead>
                <tr>
                    <th style="width: 10px">#</th>
                    <th>Service Name</th>
                    <th>Service Price</th>
                    <th style="width: 40px">Action</th>
                </tr>
                </thead>
                <tbody>

                <?php

                if($services !=false){
                    $count=0;
                    foreach($services as $services){
                        $count++;
                        ?>
                        <tr>
                            <td><?php echo $count;?>.</td>
                            <td><?php echo $services->service_name ?></td>
                            <td>
                                <span>₹</span><?php echo $services->service_price ?>
                            </td>

                            <td style="width: 25%"><span> <a href="#" onclick="return editOption(<?php echo $services->service_id ?>, 'service' )"><span class="glyphicon glyphicon-pencil"></span></a> |
                                <a href="#" onclick="return deleteOption(<?php echo $services->service_id ?>, 'service' )" ><span class="glyphicon glyphicon-trash"></span></a></span>
                            </td>
                        </tr>
                    <?php } }?>


                </tbody>
            </table>
        </div>
        <!-- /.box-body -->
    </div>
    <!-- /.box -->
</div>
<!-- /.col -->
<div class="col-md-6">

    <div class="box">
        <div class="box-header">
            <h3 class="box-title"> <span class="glyphicon glyphicon-hand-down"></span>&nbsp;Our Packages</h3>
            <a href="<?php echo base_url('add-package')?>" class="pull-right btn btn-default btn-sm"> <span class="glyphicon glyphicon-plus"></span> Add new package </a>
        </div>
        <!-- /.box-header -->
        <div class="box-body no-padding">

            <table class="table table-striped" id="package_list_table">
                <thead>
                <tr>
                    <th style="width: 10px">#</th>
                    <th>Package Name</th>
                    <th>Price</th>
                    <th>Period</th>
                    <th style="width: 40px">Action</th>
                </tr>
                </thead>
                <tbody>

                <?php

                if($all_packages !=false){
                    $count=0;
                    foreach($all_packages as $all_packages){
                        $count++;
                        ?>
                    <tr>
                        <td><?php echo $count;?>.</td>
                        <td><?php echo $all_packages->package_name ?></td>
                        <td>
                            <span>₹</span><?php echo $all_packages->package_price ?>
                        </td>
                        <td>
                            <?php echo $all_packages->package_period ?> Months
                        </td>
                        <td style="width: 25%"><span> <a href="#" onclick="return editOption(<?php echo $all_packages->package_id ?>, 'package' )"><span class="glyphicon glyphicon-pencil"></span></a> |
                                <a href="#" onclick="return deleteOption(<?php echo $all_packages->package_id ?>, 'package' )" ><span class="glyphicon glyphicon-trash"></span></a></span>
                        </td>
                    </tr>
                <?php } }?>


                </tbody>
            </table>
        </div>
        <!-- /.box-body -->
    </div>
    <!-- /.box -->
</div>
<!-- /.col -->
</div>
<!-- /.row -->


<!-- /.box -->
<div id="deleteServiceModal" class="modal fade" role="dialog">
    <input type="hidden" id="temp_service_id_to_delete" value="">
    <div class="modal-dialog">
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title"> Delete Service </h4>
            </div>
            <div class="modal-body">

                <div class="">
                    <div class="box-body box-profile delete-service-message">
                        <p> Are you sure to delete this Service ? </p>
                    </div>
                    <!-- /.box-body -->
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" onclick="deleteOption('','delete_service')" >Delete</button>
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            </div>
        </div>

    </div>
</div>
<div id="editServiceModal" class="modal fade" role="dialog">
    <div class="modal-dialog">
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title"> Edit Service </h4>
            </div>
            <div class="modal-body " id="edit-service-body">
                <div class="">
                    <div class="box-body box-profile">
                        <p> Please edit package ? </p>
                    </div>
                    <!-- /.box-body -->
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-primary" id="update_service_conform">Update Service</button>
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            </div>
        </div>

    </div>
</div>

<div id="clientinfomodal" class="modal fade" role="dialog">
    <div class="modal-dialog">
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title"> Clients Information </h4>
            </div>
            <div class="modal-body" id="view_client_body">

            </div>
            <div class="modal-footer">
<!--                <button type="button" class="btn btn-default" >Submit</button>-->
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            </div>
        </div>

    </div>
</div>


<div id="clientInfoModaltakenService" class="modal fade" role="dialog">
    <div class="modal-dialog">
        <!-- Modal content-->
        <div class="modal-content" id="takenServiceBodyModal">

        </div>

    </div>
</div>
<div id="blockUserModal" class="modal fade" role="dialog">
    <div class="modal-dialog">
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title"> Block Jhon smith </h4>
            </div>
            <div class="modal-body">
                <div class="">
                    <div class="box-body box-profile">
                        <p> Are you sure to block this user ? </p>
                    </div>
                    <!-- /.box-body -->
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" >Block</button>
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            </div>
        </div>

    </div>
</div>

<div id="deleteUserModal" class="modal fade" role="dialog">
    <div class="modal-dialog">
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title"> Delete Jhon smith </h4>
            </div>
            <div class="modal-body">
                <div class="">
                    <div class="box-body box-profile">
                        <p> Are you sure to delete this user ? </p>
                    </div>
                    <!-- /.box-body -->
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" >Delete</button>
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            </div>
        </div>

    </div>
</div>
<div id="deletePackageModal" class="modal fade" role="dialog">
    <input type="hidden" id="temp_package_id_to_delete" value="">
    <div class="modal-dialog">
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title"> Delete Package </h4>
            </div>
            <div class="modal-body">

                <div class="">
                    <div class="box-body box-profile delete-package-message">
                        <p> Are you sure to delete this Package ? </p>
                    </div>
                    <!-- /.box-body -->
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" onclick="deleteOption('','delete_package')" >Delete</button>
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            </div>
        </div>

    </div>
</div>
<div id="editPackageModal" class="modal fade" role="dialog">
    <div class="modal-dialog">
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title"> Edit package </h4>
            </div>
            <div class="modal-body " id="edit-package-body">
                <div class="">
                    <div class="box-body box-profile">
                        <p> Please edit package ? </p>
                    </div>
                    <!-- /.box-body -->
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-primary" id="update_package_conform">Update Package</button>
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            </div>
        </div>

    </div>
</div>

<script type="text/javascript">
    $(document).on('click',"#update_service_conform", function(){
        var service_id= $("#edited_service_id").val();
        var service_name = $("#service_name").val();
        var service_price = $("#service_price").val();

        jQuery.ajax({
            type: 'POST',
            url: "<?php echo base_url('update-service')?>",
            dataType: 'json',
            data: {service_id:service_id, service_name:service_name, service_price:service_price},
            success: function (data) {
                if(data.message == true){
                    $("#edit-service-body").html('<div class="box-body box-profile"> <p> Service successfully updated.</p></div>');
                    //$("#editClient").modal('show');
                    updatetable('service_tbl');

                    setTimeout(function(){
                        $("#edit-service-body").html('<div class="box-body box-profile"> <p></p></div>');
                    },3000);

                }
            }
        });
    });

    $(document).on('click',"#update_package_conform", function(){
        var package_id= $("#edited_package_id").val();
        var package_name = $("#package_name").val();
        var package_price = $("#package_price").val();
        var package_period = $("#package_period").val();
        var bonus = $("#bonus").val();

        jQuery.ajax({
            type: 'POST',
            url: "<?php echo base_url('update-package')?>",
            dataType: 'json',
            data: {package_id:package_id, package_name:package_name, package_price:package_price, package_period:package_period, bonus:bonus},
            success: function (data) {
                if(data.message == true){
                    $("#edit-package-body").html('<div class="box-body box-profile"> <p> Package successfully updated.</p></div>');
                    //$("#editClient").modal('show');
                    updatetable('package_tbl');
                }
            }
        });
    });

    function updatetable(tbl){
        jQuery.ajax({
            type: 'POST',
            url: "<?php echo base_url('update-table')?>",
            dataType: 'html',
            data: {tbl:tbl},
            success: function (data) {

                if(tbl =='service_tbl'){
                    $("#service_list_table").html(data);
                } else{
                    $("#package_list_table").html(data);
                }

            }
        });
    }
    function editOption(id, tbl){
       if(tbl == 'package'){
           jQuery.ajax({
               type: 'POST',
               url: "<?php echo base_url('get-package-info')?>",
               dataType: 'html',
               data: {package_id:id},
               success: function (data) {
                   // alert(data.body_htm);
                   $("#edit-package-body").html(data);
                   $("#editPackageModal").modal('show');
               }
           });
       }
        if(tbl == 'service'){
            jQuery.ajax({
                type: 'POST',
                url: "<?php echo base_url('get-service-info')?>",
                dataType: 'html',
                data: {service_id:id},
                success: function (data) {
                    // alert(data.body_htm);
                    $("#edit-service-body").html(data);
                    $("#editServiceModal").modal('show');
                }
            });

        }
    }
    function deleteOption(id, tbl){
        $("#deletepackageSuccess").text('');
        if(tbl == 'package'){
            $("#temp_package_id_to_delete").val(id);
            $("#deletePackageModal").modal('show');
        }
         if( tbl =='delete_package'){
            var temp_package_id_to_delete= $("#temp_package_id_to_delete").val();
            jQuery.ajax({
                type: 'POST',
                url: "<?php echo base_url('package-delete')?>",
                dataType: 'html',
                data: {package_id:temp_package_id_to_delete},
                success: function (data) {
                    // alert(data.body_htm);
                    $("#package_list_table").html(data);
                    $(".delete-package-message").html('<div class="form-group my-success deletepackageSuccess" style="color: green;font-weight: bold; text-align: center;">Package Deleted successfully</div>');
                }
            });
        }  if(tbl == 'service'){
            $(".delete-service-message").html(' <p> Are you sure to delete this Service ? </p>');

            $("#temp_service_id_to_delete").val(id);
            $("#deleteServiceModal").modal('show');
        }
        if( tbl =='delete_service'){
            var temp_service_id_to_delete= $("#temp_service_id_to_delete").val();
            jQuery.ajax({
                type: 'POST',
                url: "<?php echo base_url('service-delete')?>",
                dataType: 'html',
                data: {service_id:temp_service_id_to_delete},
                success: function (data) {
                    // alert(data.body_htm);
                    $("#service_list_table").html(data);
                    $(".delete-service-message").html('<div class="form-group my-success deletepackageSuccess" style="color: green;font-weight: bold; text-align: center;">Service Deleted successfully</div>');
                    setTimeout(function(){
                        $(".delete-service-message").html('<div class="form-group my-success deletepackageSuccess"></div>');
                    },3000);
                }
            });
        }
    }

    function serviceDetails(u_id){
            jQuery.ajax({
                type: 'POST',
                url: "<?php echo base_url('service-taken-info')?>",
                dataType: 'html',
                data: {service_id:u_id},
                success: function (data) {
                    // alert(data.body_htm);
                    $("#takenServiceBodyModal").html(data);
                    $("#clientInfoModaltakenService").modal('show');
                }
            });
    }

    function Client(u_id, optn){
       // $(".my-success").text('');
       // $("#temp_u_id").val(u_id);
       // $("#temp_action").val(optn);
        if(optn == 'view'){
            jQuery.ajax({
                type: 'POST',
                url: "<?php echo base_url('view-client')?>",
                dataType: 'html',
                data: {u_id:u_id},
                success: function (data) {
                    // alert(data.body_htm);
                    $("#view_client_body").html(data);
                    $("#clientinfomodal").modal('show');
                }
            });
        }
    }
    </script>
<script type="text/javascript">
    $(document).ready(function() {
        // if ( ! $.fn.DataTable.isDataTable( '#client_table' ) ) {
        $('#active_client_table, #all_client_table, #package_list_table').dataTable({
            "ordering": true,
            "lengthChange": false,
            "searching": false,
            "pageLength": 10,
            "order": [[ 4, "asc" ]],
            "info":     false
        });
        // }
    } );
</script>
<script type="text/javascript">
    $(document).ready(function() {
        // if ( ! $.fn.DataTable.isDataTable( '#client_table' ) ) {
        $('#service_list_table').dataTable({
            "ordering": true,
            "lengthChange": false,
            "searching": false,
            "pageLength": 10,
            "order": [[ 0, "asc" ]],
            "info":     false
        });
        // }
    } );
</script>