
<!-- SELECT2 EXAMPLE -->
<div class="box box-default">
    <div class="box-header with-border">
        <h3 class="box-title" style="text-align: center">Add Package</h3>
    </div>
    <!-- /.box-header -->
      <div class="box-body">
        <div class="row">
            <div class="col-md-2">
                &nbsp;
            </div>
            <div class="col-md-8">

                <?php
                if($this->session->flashdata('success')){ ?>
                    <div class="form-group my-success" style="color: green;font-weight: bold; text-align: center">
                        <?php echo $this->session->flashdata('success'); 
                         $this->session->unset_userdata('success');
                        ?> </div>
                <?php } ?>
                <form action="<?php echo base_url('add-package')?>" method="post" accept-charset="UTF-8" enctype="multipart/form-data" autocomplete="off"  >

                <div class="form-group">
                    <label>Package Name</label>
                    <input type="text" class="form-control pull-right" name="package_name" value="<?php echo set_value('package_name')?>" >
                    <?php echo form_error('package_name', '<div class="adduseradminerror">', '</div>'); ?>
                </div>

                <div class="form-group">
                    <label>Package Price </label>
                    <input type="text" class="form-control pull-right" name="package_price" value="<?php echo set_value('package_price')?>" >
                    <?php echo form_error('package_price', '<div class="adduseradminerror">', '</div>'); ?>
                </div>
                <div class="form-group">
                    <label>Package Period in months</label>
                    <input type="text" class="form-control pull-right" name="package_period" value="<?php echo set_value('package_period')?>" >
                    <?php echo form_error('package_period', '<div class="adduseradminerror">', '</div>'); ?>
                </div>

                <div class="form-group">
                    <label>Benefit / Bonus</label>
                    <input type="text" class="form-control pull-right" name="package_bonus" value="<?php echo set_value('package_bonus')?>"  >
                    <?php echo form_error('package_bonus', '<div class="adduseradminerror">', '</div>'); ?>
                </div>

                <div class="form-group ">
                    <label>&nbsp;</label>
                    <button type="submit" class="form-control btn btn-primary pull-right" name="add_package_button" value="submit"> Create Package</button>
                </div>
                <!-- /.form-group -->
                <!-- /.form-group -->
             </form>
            </div>
            <!-- /.col -->
            <div class="col-md-2">
                &nbsp;
            </div>
            <!-- /.col -->
        </div>
        <!-- /.row -->
<!-- /.row -->
    </div>
    <div class="box-footer">
        &nbsp;
    </div>
</div>
<div class="">

    <!-- /.box-header -->
      <div class="">

        <!-- /.row -->
<div class="row" style="margin-top:20px"> 
    <div class="col-md-12">

    <div class="box">
        <div class="box-header">
            <h3 class="box-title"> <span class="glyphicon glyphicon-hand-down"></span>&nbsp;Our Packages</h3>
            
        </div>
        <!-- /.box-header -->
        <div class="box-body no-padding">

            <table class="table table-striped" id="package_list_table">
                <thead>
                <tr>
                    <th style="width: 10px">#</th>
                    <th>Package Name</th>
                    <th>Price</th>
                    <th>Period</th>
                    <th>Benefit / Bonus</th>
                    <th style="width: 40px">Action</th>
                </tr>
                </thead>
                <tbody>

                <?php

                if($all_packages !=false){
                    $count=0;
                    foreach($all_packages as $all_packages){
                        $count++;
                        ?>
                    <tr>
                        <td><?php echo $count;?>.</td>
                        <td><?php echo $all_packages->package_name ?></td>
                        <td>
                            <span>₹</span><?php echo $all_packages->package_price ?>
                        </td>
                        <td>
                            <?php echo $all_packages->package_period ?> Months
                        </td>
                         <td>
                            <?php echo '₹'.$all_packages->bonus ?>
                        </td>
                        
                        <td style="width: 25%"><span> <a href="#" onclick="return editOption(<?php echo $all_packages->package_id ?>, 'package' )"><span class="glyphicon glyphicon-pencil"></span></a> |
                                <a href="#" onclick="return deleteOption(<?php echo $all_packages->package_id ?>, 'package' )" ><span class="glyphicon glyphicon-trash"></span></a></span>
                        </td>
                    </tr>
                <?php } }?>


                </tbody>
            </table>
        </div>
        <!-- /.box-body -->
    </div>
    <!-- /.box -->
</div>
<!-- /.col -->
</div>
<!-- /.row -->
    </div>

</div>

<!-- /.box -->
<div id="deletePackageModal" class="modal fade" role="dialog">
    <input type="hidden" id="temp_package_id_to_delete" value="">
    <div class="modal-dialog">
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title"> Delete Package </h4>
            </div>
            <div class="modal-body">

                <div class="">
                    <div class="box-body box-profile delete-package-message">
                        <p> Are you sure to delete this Package ? </p>
                    </div>
                    <!-- /.box-body -->
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" onclick="deleteOption('','delete_package')" >Delete</button>
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            </div>
        </div>

    </div>
</div>
<div id="editPackageModal" class="modal fade" role="dialog">
    <div class="modal-dialog">
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title"> Edit package </h4>
            </div>
            <div class="modal-body " id="edit-package-body">
                <div class="">
                    <div class="box-body box-profile">
                        <p> Please edit package ? </p>
                    </div>
                    <!-- /.box-body -->
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" id="update_package_conform">Update Package</button>
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            </div>
        </div>

    </div>
</div>

<script type="text/javascript">
    $(document).on('click',"#update_package_conform", function(){
        var package_id= $("#edited_package_id").val();
        var package_name = $("#package_name").val();
        var package_price = $("#package_price").val();
        var package_period = $("#package_period").val();
        var bonus = $("#bonus").val();

        jQuery.ajax({
            type: 'POST',
            url: "<?php echo base_url('update-package')?>",
            dataType: 'json',
            data: {package_id:package_id, package_name:package_name, package_price:package_price, package_period:package_period, bonus:bonus},
            success: function (data) {
                if(data.message == true){
                    $("#edit-package-body").html('<div class="box-body box-profile"> <p> Package successfully updated.</p></div>');
                    //$("#editClient").modal('show');
                    updatetable('package_tbl');
                    
                     setTimeout(function(){
                       $("#edit-package-body").html('<div class="box-body box-profile"> <p></p></div>');
                    },3000);
                    
                }
            }
        });
    });

    function updatetable(tbl){
        jQuery.ajax({
            type: 'POST',
            url: "<?php echo base_url('update-table')?>",
            dataType: 'html',
            data: {tbl:tbl},
            success: function (data) {
                $("#package_list_table").html(data);
            }
        });
    }
    function editOption(id, tbl){
       if(tbl == 'package'){
           jQuery.ajax({
               type: 'POST',
               url: "<?php echo base_url('get-package-info')?>",
               dataType: 'html',
               data: {package_id:id},
               success: function (data) {
                   // alert(data.body_htm);
                   $("#edit-package-body").html(data);
                   $("#editPackageModal").modal('show');
               }
           });

       }
    }
    function deleteOption(id, tbl){
        $("#deletepackageSuccess").text('');
        if(tbl == 'package'){
            $("#temp_package_id_to_delete").val(id);
            $("#deletePackageModal").modal('show');
        }
        if( tbl =='delete_package'){
            var temp_package_id_to_delete= $("#temp_package_id_to_delete").val();
            jQuery.ajax({
                type: 'POST',
                url: "<?php echo base_url('package-delete')?>",
                dataType: 'html',
                data: {package_id:temp_package_id_to_delete},
                success: function (data) {
                    // alert(data.body_htm);
                    $("#package_list_table").html(data);
                    $(".delete-package-message").html('<div class="form-group my-success deletepackageSuccess" style="color: green;font-weight: bold; text-align: center;">Package Deleted successfully</div>');
                     setTimeout(function(){
                       $(".delete-package-message").html('<div class="form-group my-success deletepackageSuccess"></div>');
                    },3000);
                }
            });
        }
    }

   
    </script>

<script type="text/javascript">
    jQuery(document).ready(function(){

        setTimeout(function(){
            $(".my-success").text(' ');
        },3000);

    });
</script>
<script type="text/javascript">
    $(document).ready(function() {
        // if ( ! $.fn.DataTable.isDataTable( '#client_table' ) ) {
        $('#package_list_table').dataTable({
            "ordering": true,
            "lengthChange": false,
            "searching": false,
            "pageLength": 10,
            "order": [[ 4, "asc" ]],
            "info":     false
        });
        // }
    } );
</script>
