<?php
   if($user_info !=false){ ?>
       <form>
           <div class="form-group">
               <label for="email">Name : </label>
               <input type="email" class="form-control" id="name" value="<?php echo $user_info->name;?>">
           </div>
           <div class="form-group">
               <label for="pwd"> Email : </label>
               <input type="text" class="form-control" id="email" value ="<?php echo $user_info->user_name;?>">
           </div>
           <div class="form-group">
               <label for="pwd"> Password </label>
               <input type="password" class="form-control" id="password" name="password" value ="">
           </div>
           <div class="form-group">
               <label for="pwd"> Phone : </label>
               <input type="text" class="form-control" id="phone" value="<?php echo $user_info->phone;?>">
           </div>
           <div class="form-group">
               <label>Select Package</label>
               <select class="form-control select2" id="package" style="width: 100%;">
                   <option  value="">Select Package</option>
                   <?php
                   if($all_package != false){
                       foreach($all_package as $all_package) {
                           ?>
                           <option value="<?php echo $all_package->package_id;?>" selected="<?php echo ($all_package->package_id == $user_info->package_id )?'selected':'';?>" ><?php echo $all_package->package_name;?></option>
                       <?php } }?>
               </select>
           </div>
           <div class="form-group">
               <label>Names of Family Members</label>
               <input type="text" class="form-control pull-right" id="family_members" value="<?php echo $user_info->family_members;?>" placeholder="Example : Jhon Smith, Silvia roy, KM Roy " >
           </div>

       </form>
  <?php  } else{ ?>
       <div class="form-group">
          No record to show
       </div>
   <?php } ?>
