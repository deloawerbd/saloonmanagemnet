
<!-- SELECT2 EXAMPLE -->
<div class="box box-default">
    <div class="box-header with-border">
        <h3 class="box-title" style="text-align: center">Add Your Service</h3>
    </div>
    <!-- /.box-header -->
    <div class="box-body">
        <div class="row">
            <div class="col-md-2">
                &nbsp;
            </div>
            <div class="col-md-8">
                <?php
                if($this->z->flashdata('success')){ ?>
                    <div class="form-group my-success" style="color: green;font-weight: bold; text-align: center">
                         <?php echo $this->session->flashdata('success'); 
                          $this->session->unset_userdata('success');
                          ?>
                        </div>
                <?php } ?>
            <form action="<?php echo base_url('add-service')?>" method="post" accept-charset="UTF-8" enctype="multipart/form-data" autocomplete="off"  >
                <div class="form-group">
                    <label>Service Name</label>
                    <input type="text" class="form-control pull-right" name="service_name" value="<?php echo set_value('service_name')?>" >
                    <?php echo form_error('service_name', '<div class="adduseradminerror">', '</div>'); ?>
                </div>
               
                <div class="form-group">
                    <label>Service Price</label>
                    <input type="text" class="form-control pull-right" name="service_price" value="<?php echo set_value('service_price')?>" >
                    <?php echo form_error('service_price', '<div class="adduseradminerror">', '</div>'); ?>
                </div>

                <div class="form-group ">
                    <label>&nbsp;</label>
                    <button type="submit" class="form-control btn btn-primary pull-right"> Submit Service</button>
                </div>
                <!-- /.form-group -->
                <!-- /.form-group -->
                </form>
            </div>
            <!-- /.col -->
            <div class="col-md-2">
                &nbsp;
            </div>
            <!-- /.col -->
        </div>
        <!-- /.row -->
    </div>
    <!-- /.box-body -->
    <div class="box-footer">
        &nbsp;
    </div>
</div>

<div class="">

    <!-- /.box-header -->
    <div class="">

        <!-- /.row -->
        <div class="row" style="margin-top:20px"> 
    <div class="col-md-12">

    <div class="box">
        <div class="box-header">
            <h3 class="box-title"> <span class="glyphicon glyphicon-hand-down"></span>&nbsp;Our Services</h3>
            
        </div>
        <!-- /.box-header -->
        <div class="box-body no-padding">

            <table class="table table-striped" id="service_list_table">
                <thead>
                <tr>
                    <th style="width: 10px">#</th>
                    <th>Service Name</th>
                    <th>Service Price</th>
                    <th style="width: 40px">Action</th>
                </tr>
                </thead>
                <tbody>

                <?php

                if($services !=false){
                    $count=0;
                    foreach($services as $services){
                        $count++;
                        ?>
                    <tr>
                        <td><?php echo $count;?>.</td>
                        <td><?php echo $services->service_name ?></td>
                        <td>
                            <span>₹</span><?php echo $services->service_price ?>
                        </td>
                        
                        <td style="width: 25%"><span> <a href="#" onclick="return editOption(<?php echo $services->service_id ?>, 'service' )"><span class="glyphicon glyphicon-pencil"></span></a> |
                                <a href="#" onclick="return deleteOption(<?php echo $services->service_id ?>, 'service' )" ><span class="glyphicon glyphicon-trash"></span></a></span>
                        </td>
                    </tr>
                <?php } }?>


                </tbody>
            </table>
        </div>
        <!-- /.box-body -->
    </div>
    <!-- /.box -->
</div>
<!-- /.col -->
</div>
    </div>
    <!-- /.box-body -->

</div>

<!-- /.box -->

<!-- /.box -->
<div id="deleteServiceModal" class="modal fade" role="dialog">
    <input type="hidden" id="temp_service_id_to_delete" value="">
    <div class="modal-dialog">
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title"> Delete Service </h4>
            </div>
            <div class="modal-body">

                <div class="">
                    <div class="box-body box-profile delete-service-message">
                        <p> Are you sure to delete this Service ? </p>
                    </div>
                    <!-- /.box-body -->
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" onclick="deleteOption('','delete_service')" >Delete</button>
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            </div>
        </div>

    </div>
</div>
<div id="editServiceModal" class="modal fade" role="dialog">
    <div class="modal-dialog">
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title"> Edit Service </h4>
            </div>
            <div class="modal-body " id="edit-service-body">
                <div class="">
                    <div class="box-body box-profile">
                        <p> Please edit package ? </p>
                    </div>
                    <!-- /.box-body -->
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" id="update_service_conform">Update Service</button>
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            </div>
        </div>

    </div>
</div>


<script type="text/javascript">
    $(document).on('click',"#update_service_conform", function(){
        var service_id= $("#edited_service_id").val();
        var service_name = $("#service_name").val();
        var service_price = $("#service_price").val();
        
        jQuery.ajax({
            type: 'POST',
            url: "<?php echo base_url('update-service')?>",
            dataType: 'json',
            data: {service_id:service_id, service_name:service_name, service_price:service_price},
            success: function (data) {
                if(data.message == true){
                    $("#edit-service-body").html('<div class="box-body box-profile"> <p> Service successfully updated.</p></div>');
                    //$("#editClient").modal('show');
                    updatetable('service_tbl');
                    
                     setTimeout(function(){
                       $("#edit-service-body").html('<div class="box-body box-profile"> <p></p></div>');
                    },3000);
                    
                }
            }
        });
    });

    function updatetable(tbl){
        jQuery.ajax({
            type: 'POST',
            url: "<?php echo base_url('update-table')?>",
            dataType: 'html',
            data: {tbl:tbl},
            success: function (data) {
                $("#service_list_table").html(data);
            }
        });
    }
    function editOption(id, tbl){
       if(tbl == 'service'){
           jQuery.ajax({
               type: 'POST',
               url: "<?php echo base_url('get-service-info')?>",
               dataType: 'html',
               data: {service_id:id},
               success: function (data) {
                   // alert(data.body_htm);
                   $("#edit-service-body").html(data);
                   $("#editServiceModal").modal('show');
               }
           });

       }
    }
    function deleteOption(id, tbl){
        if(tbl == 'service'){
             $(".delete-service-message").html(' <p> Are you sure to delete this Service ? </p>');
           
            $("#temp_service_id_to_delete").val(id);
            $("#deleteServiceModal").modal('show');
        }
        if( tbl =='delete_service'){
            var temp_service_id_to_delete= $("#temp_service_id_to_delete").val();
            jQuery.ajax({
                type: 'POST',
                url: "<?php echo base_url('service-delete')?>",
                dataType: 'html',
                data: {service_id:temp_service_id_to_delete},
                success: function (data) {
                    // alert(data.body_htm);
                    $("#service_list_table").html(data);
                    $(".delete-service-message").html('<div class="form-group my-success deletepackageSuccess" style="color: green;font-weight: bold; text-align: center;">Service Deleted successfully</div>');
                     setTimeout(function(){
                       $(".delete-service-message").html('<div class="form-group my-success deletepackageSuccess"></div>');
                    },3000);
                }
            });
        }
    }

   
    </script>
    
<script type="text/javascript">
    jQuery(document).ready(function(){

        setTimeout(function(){
            $(".my-success").text(' ');
        },3000);

    });
    </script>
    
<script type="text/javascript">
    $(document).ready(function() {
        // if ( ! $.fn.DataTable.isDataTable( '#client_table' ) ) {
        $('#service_list_table').dataTable({
            "ordering": true,
            "lengthChange": false,
            "searching": false,
            "pageLength": 10,
            "info":     false
        });
        // }
    } );
</script>
