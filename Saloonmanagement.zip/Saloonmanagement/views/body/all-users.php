
<div class="col-md-12">
    <div class="box">
        <div class="box-header">
            <h3 class="box-title"><span class="glyphicon glyphicon-user"></span> &nbsp;All Registered Customers</h3>
            <a href="<?php echo base_url('add-user')?>" class="pull-right btn btn-default btn-sm"> <span class="glyphicon glyphicon-plus"></span> Add new Member </a>
        </div>
        <!-- /.box-header -->
        <div class="box-body no-padding">
            <table class="table table-condensed client_table" id="client_table">
              <thead>
                <tr>
                    <th style="width: 10px">#</th>
                    <th>Name </th>
                    <th>Phone</th>
                    <th>Family Members</th>
                    <th>Registered Date</th>
                    <th>Expiry Date</th>
                    <th>Available Balance</th>
                    <th>Profile</th>
                    <th style="width: 40px">Status</th>
                    <th>Action</th>
                </tr>
              </thead>
                <tbody>

                <?php
                    $count=0;
                     if($all_users !=false){
                         foreach($all_users as $all_users){
                             $count++;
                         ?>
                         <tr>
                             <td><?php echo $count;?></td>
                             <td><?php echo $all_users->name;?></td>
                             <td><?php echo $all_users->phone;?></td>
                             <td><?php echo trim($all_users->family_members,',');?></td>
                             <td> <?php echo date_format(date_create($all_users->registered_date),'d-m-Y');?> </td>
                             <td> <?php echo date_format(date_create($all_users->expire_on),'d-m-Y');?></td>
                             <td>
                                 <?php
                                       echo $all_users->current_balance;
                                  ?>
                             </td>
                             <td> <a target="_blank" href="<?php echo base_url('user-details/'.$all_users->user_id)?>">Profile</a> </td>
                             <td> <span class="label <?php echo ($all_users->user_status == 0)?'label-warning':'label-success';?> "> <?php echo ($all_users->user_status == 0)?'Inactive':'Active';?> </span> </td>
                             <td style="width: 10%"><span>
                                     <a href="#" onclick="return Client(<?php echo $all_users->user_id;?>, 'edit')"> <span class="glyphicon glyphicon-pencil"></span></a> |
                                     <?php if ($all_users->user_status == 0){ ?>
                                         <a href="#" onclick="return Client(<?php echo $all_users->user_id;?>, 'active')" ><span class="glyphicon glyphicon-ok"></span></a> |
                                     <?php } else{ ?>
                                         <a href="#" onclick="return Client(<?php echo $all_users->user_id;?>, 'deactive')"  ><span class="glyphicon glyphicon-ban-circle"></span></a> |
                                    <?php }?>

                      <a href="#" onclick="return Client(<?php echo $all_users->user_id;?>, 'delete')"  ><span class="glyphicon glyphicon-trash"></span></a>
                                 </span>
                             </td>
                         </tr>
                    <?php }} else{ ?>
                         <tr>
                             <td colspan="8"> No users yet</td>
                         </tr>
                    <?php }
                ?>
                </tbody>

            </table>

        </div>

        <!-- /.box-body -->
    </div>

    <!-- /.box -->
</div>


<div id="activeModal" class="modal fade" role="dialog">
    <div class="modal-dialog">
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title"> Active user </h4>
            </div>
            <div class="modal-body">
                <div class="form-group my-success activeModal" style="color: green;font-weight: bold; text-align: center;"></div>
                <div class="">
                    <div class="box-body box-profile">
                        <p> Are you sure to active this user ? </p>
                    </div>
                    <!-- /.box-body -->
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-primary" id="active_user" >Active</button>
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            </div>
        </div>

    </div>
</div>

<div id="deactiveModal" class="modal fade" role="dialog">
    <div class="modal-dialog">
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title"> Deactive </h4>
            </div>
            <div class="modal-body">
                <div class="">
                    <div class="form-group my-success deactiveModal" style="color: green;font-weight: bold; text-align: center;"></div>
                    <div class="box-body box-profile">
                        <p> Are you sure to deactive this user ? </p>
                    </div>
                    <!-- /.box-body -->
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" id="deactive_user" >Deactive</button>
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            </div>
        </div>

    </div>
</div>

<div id="deleteUserModal" class="modal fade" role="dialog">
    <div class="modal-dialog">
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title"> Delete Jhon smith </h4>
            </div>
            <div class="modal-body">
                <div class="">
                    <div class="form-group my-success deleteUserModal" style="color: green;font-weight: bold; text-align: center;"></div>
                    <div class="box-body box-profile">
                        <p> Are you sure to delete this user ? </p>
                    </div>
                    <!-- /.box-body -->
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" id="delete_user" >Delete</button>
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            </div>
        </div>

    </div>
</div>
<div id="editClient" class="modal fade" role="dialog">
    <div class="modal-dialog">
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Update Information</h4>
            </div>
            <div class="modal-body">
                <div class="form-group my-success editClient" style="color: green;font-weight: bold; text-align: center;"></div>
                <div class="">
                    <div class="box-body box-profile " id="edit-client-body">

                    </div>
                    <!-- /.box-body -->
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-primary"  id="update_user" >Update</button>
            </div>
        </div>

    </div>
</div>
<input type="hidden" id="temp_u_id" value="">
<input type="hidden" id="temp_action" value="">
<script type="text/javascript">
   function Client(u_id, optn){
       $(".my-success").text('');
      $("#temp_u_id").val(u_id);
      $("#temp_action").val(optn);
       if(optn == 'edit'){
           jQuery.ajax({
               type: 'POST',
               url: "<?php echo base_url('get-client')?>",
               dataType: 'html',
               data: {u_id:u_id},
               success: function (data) {
                  // alert(data.body_htm);
                 $("#edit-client-body").html(data);
                  $("#editClient").modal('show');
               }
           });
       } else if(optn =='active'){
           $("#activeModal").modal('show');
       } else if(optn =='deactive'){
           $("#deactiveModal").modal('show');
       } else if(optn =='delete'){
           $("#deleteUserModal").modal('show');
       }
   }
       jQuery(document).ready(function(){
           $("#delete_user, #deactive_user, #active_user").click(function(e){
               $(".my-success").text('');
               var u_id= $("#temp_u_id").val();
               var optn = $("#temp_action").val();
               jQuery.ajax({
                   type: 'POST',
                   url: "<?php echo base_url('client_manage')?>",
                   dataType: 'json',
                   data: {u_id:u_id, optn:optn},
                   success: function (data) {
                       if(data.pass !='error'){
                           if(optn =='edit'){
                               $("#editClient").modal('show');
                               $(".editClient").text();
                           } else if(optn =='active'){
                               $("#activeModal").modal('show');
                               $(".activeModal").text('USER ACTIVATED');
                               setTimeout(function(){
                                   $(".activeModal").text('');
                               },2000);

                           } else if(optn =='deactive'){
                               $("#deactiveModal").modal('show');
                               $(".deactiveModal").text('USER DEACTIVATED');
                               setTimeout(function(){
                                   $(".deactiveModal").text(' ');
                               },2000);

                           } else if(optn =='delete'){
                               $("#deleteUserModal").modal('show');
                               $(".deleteUserModal").text('USER DELETED');
                               setTimeout(function(){
                                   $(".deleteUserModal").text(' ');
                               },2000);
                           }
                           updatetable('users');
                       }
                   }
               });

           });

           $("#update_user").click(function(e){
               $(".my-success").text('');
               var u_id= $("#temp_u_id").val();
               var name = $("#name").val();
               var email = $("#email").val();
               var phone = $("#phone").val();
               var packages = $("#package").val();
               var family_members = $("#family_members").val();
               var password = $("#password").val();
               jQuery.ajax({
                   type: 'POST',
                   url: "<?php echo base_url('update-client')?>",
                   dataType: 'json',
                   data: {u_id:u_id, name:name, email:email, phone:phone, packages:packages, family_members:family_members, password:password},
                   success: function (data) {
                       if(data.status == true){
                           $(".editClient").text('SUCCESSFULLY UPDATED');
                           $("#editClient").modal('show');
                           updatetable('users');
                           setTimeout(function(){
                               $(".editClient").text(' ');
                           },2000);
                       }
                   }
               });

           });
       });
    function updatetable(tbl){
        jQuery.ajax({
            type: 'POST',
            url: "<?php echo base_url('update-table')?>",
            dataType: 'html',
            data: {tbl:tbl},
            success: function (data) {
                $(".client_table").html(data);
                $("#temp_u_id").val('');
                $("#temp_action").val('');
            }
        });
    }
    </script>
<script type="text/javascript">
    $(document).ready(function() {

       // if ( ! $.fn.DataTable.isDataTable( '#client_table' ) ) {
            $('#client_table').dataTable({
                "ordering": true,
                "lengthChange": false,
                "searching": true,
                "info":     false
            });
       // }
    } );
</script>