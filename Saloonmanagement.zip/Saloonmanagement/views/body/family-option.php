
<link rel="stylesheet" href="<?php echo base_url()?>assets/plugins/select2/select2.min.css">
<label>Family Members</label>
<select class="form-control select2" id="family_members" multiple="multiple" name="family_members[]" style="width: 100%;" >
    <?php
    if($family_member != false && $family_member !=''){
        $f_members = explode(',', $family_member->family_members);
        ?>
        <option selected="selected" value="<?php echo $family_member->name;?>"><?php echo $family_member->name;?></option>
        <?php
        for($i = 0 ; $i< sizeof($f_members); $i++){ ?>
            <option value="<?php echo $f_members[$i];?>"><?php echo $f_members[$i];?></option>
 <?php    }
       } else { ?>
        <option value="">No family members added</option>
     <?php }?>
</select>

<script src="<?php echo base_url()?>assets/plugins/select2/select2.full.min.js"></script>
<script>
    $(function () {
        //Initialize Select2 Elements
        $("#family_members").select2({
            placeholder: "Select Family Member",
            allowClear: true
        });

    });

    $(document).on('change','#family_members',function() {
        var balance = parseInt($("#user option:selected").attr('user_balance'));
        var service_list = $("#service_id ").val();
        var members = parseInt($("#family_members").val().length);
        var count_item = parseInt(service_list.size);
        var tax_percent = parseInt($("#tax_percent").val());
        var count_balance=0;
        jQuery.each(service_list, function(i, values){
            var a = parseInt($("#service_id_"+values).val());
            count_balance = parseInt(count_balance)+a;

        });
        var calculated_balance = parseInt(count_balance*members);

        var tax = parseInt((calculated_balance*tax_percent)/100);
        var amount_to_pay = parseInt(calculated_balance+tax);

        $('#tax').val(tax); // Tax amount only
        $('.tax-div').html('<div class="disable">'+tax+'</div>');
        $('#total_amount').val(amount_to_pay); // balance with tx
        $('.total-amount-div').html('<div class="disable">'+amount_to_pay+'</div>');
        $("#hidden_user_value").val(balance); // Current balance of users
    } );

</script>