
<!-- SELECT2 EXAMPLE -->
<div class="box box-default">
    <div class="box-header with-border">
        <h3 class="box-title" style="text-align: center">Member Registration</h3>
    </div>
    <!-- /.box-header -->
    <div class="box-body">
        <div class="row">
            <div class="col-md-2">
                &nbsp;
            </div>
            <div class="col-md-8">
                <?php
                if($this->session->flashdata('registration_success')){ ?>
                    <div class="form-group my-success" style="color: green;font-weight: bold; text-align: center">
                        <?php echo $this->session->flashdata('registration_success');
                        $this->session->unset_userdata('registration_success');
                        ?>
                        </div>
                <?php }
                ?>
                <div class="form-group">
                    <label class="success">Full Name</label>
                </div>
                <form action="<?php echo base_url('add-user')?>" method="post" accept-charset="UTF-8" enctype="application/x-www-form-urlencoded" autocomplete="off"  id="add_user_form">
                <div class="form-group">
                    <label>Select Package</label>
                    <select class="form-control select2" style="width: 100%;" name="package" id="package">
                        <option  value="">Select Package</option>
                        <?php
                           if($all_package != false){
                                foreach($all_package as $all_package) {
                               ?>
                               <option value="<?php echo $all_package->package_id;?>"><?php echo $all_package->package_name;?></option>
                           <?php } }?>

                    </select>
                    <?php echo form_error('package', '<div class="adduseradminerror">', '</div>'); ?>
                    <div class="error msg adduseradminerror package"></div>
                </div>
                <!-- /.form-group -->

                <div class="form-group">
                    <label>Full Name</label>
                    <input type="text" class="form-control pull-right" name="name" id="name" value="<?php echo set_value('name')?>" >
                    <?php echo form_error('name', '<div class="adduseradminerror">', '</div>'); ?>
                    <div class="error msg adduseradminerror name"></div>
                </div>
                <div class="form-group">
                    <label>Phone </label>
                    <input type="text" class="form-control pull-right" name="phone" id="phone" value="<?php echo set_value('phone')?>" >
                    <?php echo form_error('phone', '<div class="adduseradminerror">', '</div>'); ?>
                    <div class="error msg adduseradminerror phone"></div>
                </div>
                <div class="form-group">
                    <label>Username / Email  </label>
                    <input type="text" class="form-control pull-right" name="user_name" id="email" value="<?php echo set_value('user_name')?>" >
                    <?php echo form_error('user_name', '<div class="adduseradminerror">', '</div>'); ?>
                    <div class="error msg adduseradminerror email"></div>
                </div>
                <div class="form-group">
                    <label>Password </label>
                    <br>
                    <input type="password" class="form-control " style="width: 65%; float: left" name="password" id="password" value="" >
                    <button type="button" class="form-control btn btn-primary " style="width: 30%; float: right" id="generate_password"> Generate password</button>
                    <br><?php echo form_error('password', '<div class="adduseradminerror">', '</div>'); ?>
                    <div class="error msg adduseradminerror password" style="display: inline"></div>
                </div>
                <!-- /.form-group -->

                <div class="form-group">
                    <label>Names of Family Members</label>
                    <input type="text" class="form-control pull-right" placeholder="Example : Jhon Smith, Silvia roy, KM Roy" value="<?php echo set_value('family_members')?>" name="family_members" >
                    <div class="error msg adduseradminerror"></div>
                </div>
                <div class="form-group ">
                    <label>&nbsp;</label>
                    <button type="submit" class="form-control btn btn-primary pull-right"> Register Member</button>
                </div>
               </form>

            </div>
            <!-- /.col -->
            <div class="col-md-2">
                    &nbsp;
            </div>
            <!-- /.col -->
        </div>
        <!-- /.row -->
    </div>
    <!-- /.box-body -->
    <div class="box-footer">
      &nbsp;
    </div>
</div>
<!-- /.box -->
<!---->
<!---->
<script type="text/javascript">
    jQuery(document).ready(function(){

        setTimeout(function(){
            $(".my-success").text(' ');
        },3000);

//        jQuery("#add_user_form").submit(function(e){
//            e.preventDefault();
//            var error_status=true;
//
//            jQuery('.adduseradminerror').text('');
//            jQuery('.adduseradminerror').hide();
//
//            var package=jQuery('#package option:selected').val();
//            if(package.length =='' ){
//                error_status=false;
//                jQuery('.package').text('Please select package.');
//                jQuery('.package').show();
//                // preventDefault();
//
//            }
//            var name=jQuery('#name').val();
//            if(name.length<=2 ){
//                error_status=false;
//                jQuery('.name').text('Enter full name and that should be at least 3 characters.');
//                jQuery('.name').show();
//                // preventDefault();
//
//            }
//            var password=jQuery('#password').val();
//            if(password.length <= 5){
//                error_status=false;
//                jQuery('.password').show();
//                jQuery('.password').text('Enter password and that should be at least 5 characters.');
//                // preventDefault();
//
//            }
//            var email=jQuery('#email').val();
//            if(isValidEmailAddress(email)==false){
//                error_status=false;
//
//                jQuery('.email').text('Please enter valid email');
//                jQuery('.email').show();
//                // preventDefault();
//            }
//
//            var mobile=jQuery('#phone').val();
//            if(validatePhone(mobile)==false){
//                error_status=false;
//                jQuery('.phone').text('Please enter valid phone');
//                jQuery('.phone').show();
//
//                // preventDefault();
//            }
//            if(error_status==true){
//              //  e.preventDefault();
//                $( "#add_user_form" ).submit();
//               // jQuery("#add_user_form").submit();
//
//            }
//
//        });

        jQuery("#generate_password").click(function(){
            jQuery.ajax({
                type: 'POST',
                url: "<?php echo base_url('auto-pass-generate')?>",
                dataType: 'json',
                data: {},
                success: function (data) {
                    if(data.pass !='error'){
                       // var pass = ;
                        jQuery("#password").val(data.pass);
                        jQuery("#password").attr('type','text');

                    }
                }
            });
        });

    });

    function isValidEmailAddress(emailAddress) {
        var pattern = /^([a-z\d!#$%&'*+\-\/=?^_`{|}~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]+(\.[a-z\d!#$%&'*+\-\/=?^_`{|}~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]+)*|"((([ \t]*\r\n)?[ \t]+)?([\x01-\x08\x0b\x0c\x0e-\x1f\x7f\x21\x23-\x5b\x5d-\x7e\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|\\[\x01-\x09\x0b\x0c\x0d-\x7f\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))*(([ \t]*\r\n)?[ \t]+)?")@(([a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|[a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF][a-z\d\-._~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]*[a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])\.)+([a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|[a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF][a-z\d\-._~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]*[a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])\.?$/i;
        return pattern.test(emailAddress);
    }
    function validatePhone(phone){
        intRegex = /[0-9 -()+]+$/;
        if((phone.length < 6) || (!intRegex.test(phone)))
        {
            return false;
        }  else{
            return true;
        }
    }



</script>