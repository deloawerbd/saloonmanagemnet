<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Saloon Software| Log in</title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <!-- Bootstrap 3.3.6 -->
    <link rel="stylesheet" href="<?php echo base_url()?>assets//bootstrap/css/bootstrap.min.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
    <!-- Ionicons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="<?php echo base_url()?>assets/dist/css/AdminLTE.min.css">
    <!-- iCheck -->
    <link rel="stylesheet" href="<?php echo base_url()?>assets/plugins/iCheck/square/blue.css">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/bootstrap/css/custome-style.css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>
<body class="hold-transition login-page">
<div class="login-box">
    <div class="login-logo">
        <a href="<?php echo base_url('dashboard')?>"><b>Login to</b> Software</a>
    </div>
    <!-- /.login-logo -->
    <div class="login-box-body">
        <p class="login-box-msg" style="font-weight: bold; font-size: 14px">Sign in to get access</p>

        <form action="<?php echo base_url('login')?>" method="post" enctype="multipart/form-data" autocomplete="off">
            <?php
            if($this->session->flashdata('success')){ ?>
                <div class="form-group my-success" style="color: red;font-weight: bold; text-align: center"><?php echo $this->session->flashdata('success'); ?> </div>
            <?php }  ?>

            <label>User Name</label>
            <div class="form-group has-feedback" style="margin-bottom: 0px">
                <input type="text" class="form-control" name="username" placeholder="Email" autocomplete="off">
                <span class="glyphicon glyphicon-envelope form-control-feedback"></span>
            </div>
            <?php echo form_error('username', '<div class="adduseradminerror">', '</div>'); ?>

            <br>
            <label>Password</label>
            <div class="form-group has-feedback" style="margin-bottom: 0px">
                <input type="password" class="form-control" name="password" placeholder="Password" autocomplete="off">
                <span class="glyphicon glyphicon-lock form-control-feedback"></span>
            </div>
            <?php echo form_error('password', '<div class="adduseradminerror">', '</div>'); ?>
            <br>
            <div class="row">
                <div class="col-xs-8">
<!--                    <div class="checkbox icheck">-->
<!--                        <label>-->
<!--                            <input type="checkbox"> Remember Me-->
<!--                        </label>-->
<!--                    </div>-->
                </div>
                <!-- /.col -->
                <div class="col-xs-4">
                    <button type="submit" class="btn btn-primary btn-block btn-flat">Sign In</button>
                </div>
                <!-- /.col -->
            </div>
        </form>

        <div class="social-auth-links text-center">  </div>
        <!-- /.social-auth-links -->
        <a href="#" data-toggle="modal" data-target="#myModal">I forgot my password</a>
        <br>
<!--        <a href="register.html" class="text-center">Register a new membership</a>-->

    </div>
    <!-- /.login-box-body -->
</div>
<!-- /.login-box -->

<div id="myModal" class="modal fade" role="dialog">
    <div class="modal-dialog">

        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Forgot password ? </h4>
            </div>
            <div class="modal-body">
                <div class="form-group" style="margin-bottom: 0px">
                  <span class="success_text" style="color: green"></span>
                  <span class="error_text" style="color: #ff0000"></span>
                </div>
                <div class="form-group" >
                    <label>Email / Username</label>
                    <p><input type="text" class="form-control" name="user_name" id="user_name"></p>
                </div>

            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-primary" id="forgot_password_submit" >Submit</button>
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            </div>
        </div>

    </div>
</div>

<!-- jQuery 2.2.3 -->
<script src="<?php echo base_url()?>assets/plugins/jQuery/jquery-2.2.3.min.js"></script>
<!-- Bootstrap 3.3.6 -->
<script src="<?php echo base_url()?>assets/bootstrap/js/bootstrap.min.js"></script>
<!-- iCheck -->
<script src="<?php echo base_url()?>assets/plugins/iCheck/icheck.min.js"></script>
<script>
    $(function () {
        $('input').iCheck({
            checkboxClass: 'icheckbox_square-blue',
            radioClass: 'iradio_square-blue',
            increaseArea: '20%' // optional
        });
    });

    $("#forgot_password_submit").click(function(e){
       var user_name = $("#user_name").val();
        jQuery.ajax({
            type: 'POST',
            url: "<?php echo base_url('retrieve-pass')?>",
            dataType: 'json',
            data: {user_name:user_name},
            success: function (data) {

                if(data.error == true){
                   $(".error_text").text(data.message);
                } else{
                    $(".success_text").text(data.message);
                }

                setTimeout(function(){
                    $(".error_text .success_text").text(' ');
                },3000);

            }
        });
    });
</script>
</body>
</html>
