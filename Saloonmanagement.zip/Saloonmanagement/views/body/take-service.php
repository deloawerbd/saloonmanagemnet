
<!-- SELECT2 EXAMPLE -->
<div class="box box-default">
    <div class="box-header with-border">
        <h3 class="box-title" style="text-align: center">Avail Service</h3>
    </div>
    <!-- /.box-header -->
    <div class="box-body">
        <div class="row">
            <div class="col-md-2">
                &nbsp;
            </div>
            <div class="col-md-8">
                <div class="form-group error-low-balance" style="color: red;font-weight: bold; text-align: center">
                    </div>

                <?php
                if($this->session->flashdata('success')){ ?>
                    <div class="form-group my-success" style="color: green;font-weight: bold; text-align: center">
                        <?php echo $this->session->flashdata('success');
                         $this->session->unset_userdata('success');
                         ?> </div>
                <?php } elseif($this->session->flashdata('no_balance')){ ?>
                    <div class="form-group my-success" style="color: red;font-weight: bold; text-align: center">
                        <?php echo $this->session->flashdata('no_balance'); 
                         $this->session->unset_userdata('no_balance');
                         ?> </div>
                    <?php
                } ?>
              <form action="<?php echo base_url('take-service')?>" method="post" id="avail_service_form" accept-charset="UTF-8" enctype="multipart/form-data" autocomplete="off" >
                <input type="hidden" name="hidden_user_value" id="hidden_user_value" value="">
<!--                <input type="hidden" name="hidden_calculated" id="hidden_calculated" value="">-->
                <input type="hidden" name="hidden_tax" id="hidden_tax" value="">
                  <div class="form-group">
                    <label>Register Name</label>
                    <select class="form-control select2" style="width: 100%;" name="user_id" id="user">
                        <option selected="selected" value="">Select User</option>
                        <?php
                        if($users != false){
                            foreach($users as $users) {
                                ?>
                                <option contact="<?php echo $users->phone;?>" expdt="<?php echo date_format(date_create($users->expire_on),'d-m-Y');?>" user_balance="<?php echo $users->current_balance;?>" customer_name="<?php echo $users->name;?>" value="<?php echo $users->user_id;?>">
                                    <?php echo $users->name.' (<label  class="price-class">Available Balance : ₹'.$users->current_balance.'</label>)';?>
                                    </option>
                            <?php } }?>
                    </select>
                    <?php echo form_error('user_id', '<div class="adduseradminerror">', '</div>'); ?>

                </div>
                  <div class="form-group family-div">

                  </div>

                  <div class="row">
                      <div class="col-md-4 contact-div">
                          <label>Contact No</label>
                          <div class="disable">&nbsp;</div>
                      </div>
                      <div class="col-md-4">
                          <div class="form-group expire-div">
                              <label>Expiry Date</label>
                              <div class="disable">&nbsp;</div>
                          </div>

                      </div>
                      <div class="col-md-4">
                          <div class="form-group ">
                              <label>Reference No</label>
                              <input type="text" class="form-control" name="remark" id="remark" required="required" placeholder="INV00025">
                          </div>
                      </div>
                  </div>



                <div class="form-group">
                    <?php
                    if($services_2 != false){
                        foreach($services_2 as $services_2) { ?>
                            <input type="hidden" id="service_id_<?php echo $services_2->service_id;?>" class="hidden_s_price" value="<?php echo $services_2->service_price;?>">

                        <?php } }?>

                    <label>Service</label>
                    <select class="form-control select2" id="service_id" name="service_id[]" multiple="multiple" style="width: 100%;">
                        <?php
                        if($services != false){
                            foreach($services as $services) {   ?>
                                <option value="<?php echo $services->service_id;?>" >
                                    <?php echo $services->service_name.' (₹'.$services->service_price.')';?></option>
                            <?php } }?>
                    </select>
                    <?php echo form_error('service_id', '<div class="adduseradminerror">', '</div>'); ?>
                </div>


                  <div class="row">
                       <div class="col-md-6">
                           <div class="form-group">
                               <label>Service Tax (<?php echo isset($tax_percent) ? $tax_percent : 0;?>%)</label>
                               <input type="hidden" class="form-control" disabled name="tax_percent" id="tax_percent" value="<?php echo isset($tax_percent) ? $tax_percent:0;?>">
                               <input type="hidden" class="form-control" name="tax" id="tax" >
                               <span class="tax-div"><div class="disable">0</div></span>
                           </div>

                       </div>
                      <div class="col-md-6">

                          <div class="form-group total_amount_div">
                              <label>Total Amount</label>
                              <input type="hidden" class="form-control" name="total_amount" id="total_amount" >
                              <span class="total-amount-div"><div class="disable">0</div> </span>
                          </div>
                      </div>
                  </div>



                <div class="form-group ">
                    <label>&nbsp;</label>
                    <button type="submit" class="form-control btn btn-primary pull-right"> Submit Request</button>
                </div>
              </form>
            </div>
            <!-- /.col -->
            <div class="col-md-2">
                &nbsp;
            </div>
            <!-- /.col -->
        </div>
        <!-- /.row -->
    </div>
    <!-- /.box-body -->
    <div class="box-footer">
        &nbsp;
    </div>
</div>
<!-- /.box -->
<script type="text/javascript">
    $(document).on('change','#user',function() {
        // Filed will be reset while user change
        $('#tax').val(''); // Tax amount only
        $('.tax-div').html('<div class="disable">0</div>');
        $('#total_amount').val(''); // balance with tx
        $('.total-amount-div').html('<div class="disable">0</div>');
        $("#hidden_user_value").val(''); // Current balance of users
        $("#service_id").select2("val", "");

       var con =  $( "#user option:selected" ).attr('contact');
        var expdte= $( "#user option:selected" ).attr('expdt');
       if(con.length >0 ){
           $('.contact-div').html(' <label>Contact No.</label> <div class="disable">'+con+'</div>');
           $('.expire-div').html(' <label>Expiry Date.</label> <div class="disable">'+expdte+'</div>');
           var user_id = $(this).val();
           jQuery.ajax({
               type: 'POST',
               url: "<?php echo base_url('get-family')?>",
               dataType: 'html',
               data: {user_id:user_id},
               success: function (data) {
                   // alert(data.body_htm);
                   $(".family-div").html(data);

               }
           });
       } else{
           $('.contact-div').html('<label> </label>');
       }
    } );

    $(document).on('change','#service_id',function() {
        var balance = parseInt($("#user option:selected").attr('user_balance'));
        var service_list = $("#service_id ").val();
        var members = parseInt($("#family_members").val().length);
        var count_item = parseInt(service_list.size);
        var tax_percent = parseInt($("#tax_percent").val());
        var count_balance=0;
        jQuery.each(service_list, function(i, values){
            var a = parseInt($("#service_id_"+values).val());
            count_balance = parseInt(count_balance)+a;

        });
        var calculated_balance = parseInt(count_balance*members);

        var tax = parseInt((calculated_balance*tax_percent)/100);
        var amount_to_pay = parseInt(calculated_balance+tax);

        $('#tax').val(tax); // Tax amount only
        $('.tax-div').html('<div class="disable">'+tax+'</div>');
        $('#total_amount').val(amount_to_pay); // balance with tx
        $('.total-amount-div').html('<div class="disable">'+amount_to_pay+'</div>');
        $("#hidden_user_value").val(balance); // Current balance of users
    } );

</script>


<script type="text/javascript">
    jQuery(document).ready(function(){
        setTimeout(function(){
            $(".my-success").text(' ');
        },3000);

        $( "#avail_service_form" ).submit(function( event ) {
            var c_name = $("#user option:selected").attr('customer_name');
            var u_balance = parseInt($("#user option:selected").attr('user_balance'));
            var amount_pay = parseInt($("#total_amount").val());

            if(amount_pay =='' || amount_pay <=0 ){
                $(".error-low-balance").text('Please fill up form correctly.');
                event.preventDefault();
                setTimeout(function(){
                    $(".error-low-balance").text(' ');
                },3000);
            } else{
//                // New calculation
//               // var balance = parseInt($("#user option:selected").attr('user_balance'));
//                var service_list = $("#service_id ").val();
//                var members = parseInt($("#family_members").val().length);
//                var count_item = parseInt(service_list.size);
//                var tax_percent = parseInt($("#tax_percent").val());
//                var count_balance=0;
//                jQuery.each(service_list, function(i, values){
//                    var a = parseInt($("#service_id_"+values).val());
//                    count_balance = parseInt(count_balance)+a;
//
//                });
//                var calculated_balance = parseInt(count_balance*members);
//                var tax = parseInt((calculated_balance*tax_percent)/100);
//                var amount_to_pay = parseInt(calculated_balance+tax);
//
//                $('#tax').val(tax); // Tax amount only
//                $('.tax-div').html('<div class="disable">'+tax+'</div>');
//                $('#total_amount').val(amount_to_pay); // balance with tx
//                $('.total-amount-div').html('<div class="disable">'+amount_to_pay+'</div>');
//                $("#hidden_user_value").val(balance); // Current balance of users

                if( u_balance < amount_pay ){
                    // alert(u_balance+'yyy'+amount_pay);
                    $(".error-low-balance").text( c_name+' has low balance to avail this service');
                    event.preventDefault();
                    setTimeout(function(){
                        $(".error-low-balance").text(' ');
                    },3000);
                }
            }

        });

    });
</script>

<script>
    $(function () {
        //Initialize Select2 Elements
        $("#service_id").select2({
            placeholder: "Select Services",
            allowClear: true
        });

    });
</script>
<script>
    $(function () {
        //Initialize Select2 Elements
        $("#user").select2({
            placeholder: "Select User",
            allowClear: true
        });

    });
</script>
