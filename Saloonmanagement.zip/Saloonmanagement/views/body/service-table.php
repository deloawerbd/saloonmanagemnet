   <thead>
                <tr>
                    <th style="width: 10px">#</th>
                    <th>Service Name</th>
                    <th>Service Price</th>
                    <th style="width: 40px">Action</th>
                </tr>
                </thead>
                <tbody>

                <?php

                if($services !=false){
                    $count=0;
                    foreach($services as $services){
                        $count++;
                        ?>
                    <tr>
                        <td><?php echo $count;?>.</td>
                        <td><?php echo $services->service_name ?></td>
                        <td>
                            <span>₹</span><?php echo $services->service_price ?>
                        </td>
                        
                        <td style="width: 25%"><span> <a href="#" onclick="return editOption(<?php echo $services->service_id ?>, 'service' )"><span class="glyphicon glyphicon-pencil"></span></a> |
                                <a href="#" onclick="return deleteOption(<?php echo $services->service_id ?>, 'service' )" ><span class="glyphicon glyphicon-trash"></span></a></span>
                        </td>
                    </tr>
                <?php } }?>


                </tbody>