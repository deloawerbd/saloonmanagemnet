<!DOCTYPE html>
<html style="margin: 0 auto;">
<head style="margin: 0 auto;">
    <title style="margin: 0 auto;">WHPP | Reset Password</title>
    <link href="http://fonts.googleapis.com/css?family=Open+Sans:700,300,600,400" rel="stylesheet" type="text/css" style="margin: 0 auto;">
    <link href="<?php echo base_url('assets/font-awesome/css/font-awesome.min.css')?>" rel="stylesheet" type="text/css" style="margin: 0 auto;">

</head>
<body style="margin: 0 auto;">
<div class="wrapper" style="margin: 0 auto;width: 100%;min-height: 10px;margin-top: 10px;">
    <div class="wrapper-grid" style="margin: 0 auto;width: 620px;background: #119bc8;border: 1px solid #119bc8;">
        <div class="logo-holder" style="margin: 0 auto;padding: 30px 0;background: #119bc8;">
            <a href="#" style="margin: 0 auto;text-decoration: none;"><img src="<?php echo base_url('assets/images/logo1.svg')?>" class="img-responsive wh-main-logo" style="margin: 0 auto;margin-left: 20px;"></a>
        </div>
        <div class="banner-holder" style="margin: 0 auto;background: #fff;">
            <img src="<?php echo base_url('assets/images/banner1.png')?>" style="margin: 0 auto;">

        </div>
        <div class="letter-content" style="margin: 0 auto;padding: 30px;background: #fff;">
            <h2 class="greetings-holder" style="margin: 0 auto;font-family: Open Sans;font-size: 14px;color: #6a6a6a;font-weight: 400;"> <span style="margin: 0 auto;font-weight: 600;color: #6a6a6a;"><?php echo ($subject)?$subject:'';?></span></h2>
            <p class="letter-body" style="margin: 0 auto;font-family: Open Sans;font-size: 13px;font-weight: 400;color: #6a6a6a;margin-top: 20px;text-align: justify;">
                New password has been set for <span style="margin: 0 auto;font-weight: 600;color: #119bc8;">NetaHost</span>, the world's most regarded Web hosting provider. Visit <a href="<?php echo base_url('about-us')?>" style="margin: 0 auto;text-decoration: none;color: #119bc8;">About Us</a> or <a href="<?php echo base_url('why-choose-us')?>" style="margin: 0 auto;text-decoration: none;color: #119bc8;">Why Choose Us</a> to get familiarized with all our products and services. Please take note of your account details and keep it always secured.
            </p>
            <div class="user-info-holder" style="margin: 0 auto;width: 100%;margin-top: 30px;color: #6a6a6a;">
                <table style="margin: 0 auto;float: left;font-family: Open Sans;font-size: 13px;">
                    <tr class="field-holder" style="margin: 0 auto;">
                        <td class="field" style="margin: 0 auto;color: #6a6a6a;"><i class="fa fa-unlock-alt" style="margin: 0 auto;width: 15px;color: #119bc8;font-size: 15px;"></i>New Password</td>
                        <td style="margin: 0 auto;">:</td>
                        <td class="field-val" style="margin: 0 auto;color: #119bc8;font-weight: 600;"><?php echo ($new_password)?$new_password:'';?></td>
                    </tr>
                </table>
            </div><div class="clear" style="margin: 0 auto;clear: both;"></div>
            <p class="last-text" style="margin: 0 auto;margin-top: 30px;font-family: Open Sans;font-size: 13px;font-weight: 400;color: #6a6a6a;text-align: justify;">
                Your interests and security are of utmost importance. We will appreciate it if you can send a comment or two to us. Please hesitate not to call or email us if you need any help. We are more than glad to assist you in any way at any time!
            </p>
            <p class="closing-holder" style="margin: 0 auto;margin-top: 30px;font-family: Open Sans;font-size: 13px;font-weight: 400;color: #6a6a6a;text-align: justify;">
                All the best,<br style="margin: 0 auto;">
                <span style="margin: 0 auto;font-weight: 600;color: #119bc8;">NetaHost</span> Team
            </p>
        </div>
        <div class="footer-holder" style="margin: 0 auto;padding: 15px;text-align: center;background: #0f94bf;">
            <p class="copy" style="margin: 0 auto;font-family: Open Sans;font-size: 13px;color: #fff;font-weight: 400;">&copy; 2016 <span style="margin: 0 auto;color: #3d3d3d;font-weight: 600;">NetaHost</span></p>
        </div>
    </div>
</div>
</body>
</html>